<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

//Account
Route::post('/signin', 'App\Http\Controllers\V1\Auth\AuthController@signin');
Route::post('/signin/callback', 'App\Http\Controllers\V1\Auth\AuthController@handleProviderCallback');
Route::post('/signup', 'App\Http\Controllers\V1\Auth\AuthController@signup');
Route::get('/profile-photo/{id}', 'App\Http\Controllers\V1\Auth\AuthController@profilePhotoUrl');
Route::post('/change-password', 'App\Http\Controllers\V1\Auth\AuthController@changePassword');
Route::post('/forgot-password', 'App\Http\Controllers\V1\Auth\AuthController@forgotPassword');
Route::post('/reset-password', 'App\Http\Controllers\V1\Auth\AuthController@resetPassword');
Route::get('/countries', 'App\Http\Controllers\V1\Definitions\DefinitionController@country');
Route::get('/industries', 'App\Http\Controllers\V1\Definitions\DefinitionController@industry');
Route::get('/banks', 'App\Http\Controllers\V1\Definitions\BankController@index');
Route::get('/bank-branches', 'App\Http\Controllers\V1\Definitions\BankController@branches');
Route::get('/send-password/{id}', 'App\Http\Controllers\V1\Auth\AuthController@sendPassword');
Route::post('/client/job-titles', 'App\Http\Controllers\V1\Company\JobTitleController@clientJobTitles');
Route::post('/client/employment-types', 'App\Http\Controllers\V1\Company\EmploymentTypeController@clientEmploymentTypes');

Route::middleware('auth:sanctum')->group(function () {

    // Route::middleware('audit.log')->group(function () {
    Route::get('/login-credentials/{id}', 'App\Http\Controllers\V1\Auth\AuthController@loginCredentials');
    Route::apiResource('/users', 'App\Http\Controllers\V1\Auth\UserController');
    Route::apiResource('/roles', 'App\Http\Controllers\V1\Auth\UserRoleController');
    Route::apiResource('/ability-group', 'App\Http\Controllers\V1\Auth\AbilityGroupController');
    Route::apiResource('/ability', 'App\Http\Controllers\V1\Auth\AbilitiesController');
    Route::post('/access-logs', 'App\Http\Controllers\V1\Auth\AuthController@accessLogs');

    //Company
    Route::apiResource('/company', 'App\Http\Controllers\V1\Company\CompanyController');
    Route::apiResource('/personnel', 'App\Http\Controllers\V1\Company\PersonnelController');
    Route::post('/batch-employees/{company_id}', 'App\Http\Controllers\V1\Company\PersonnelController@upload');
    Route::post('/upload-logo/{company_id}', 'App\Http\Controllers\V1\Company\CompanyController@uploadLogo');
    Route::apiResource('/departments', 'App\Http\Controllers\V1\Company\DepartmentController');
    Route::apiResource('/employment-types', 'App\Http\Controllers\V1\Company\EmploymentTypeController');
    Route::apiResource('/job-titles', 'App\Http\Controllers\V1\Company\JobTitleController');
    Route::post('/client/jobs', 'App\Http\Controllers\V1\Company\JobTitleController@getAllJobs');
    Route::apiResource('/applications', 'App\Http\Controllers\V1\Jobs\ApplicationController');
    Route::post('/applications/filter', 'App\Http\Controllers\V1\Jobs\ApplicationController@filter');
    Route::post('/applications/batch', 'App\Http\Controllers\V1\Jobs\ApplicationController@batchApplicationAction');
    Route::get('/my-applications', 'App\Http\Controllers\V1\Jobs\ApplicationController@applications');
    Route::post('/unapplied-jobs', 'App\Http\Controllers\V1\Company\JobTitleController@clientJobTitles');
    Route::post('/dashboard', 'App\Http\Controllers\V1\Jobs\ApplicationController@dashboard');
    Route::post('/download/cv', 'App\Http\Controllers\V1\Jobs\ApplicationController@downloadCv');
    Route::post('/download/cover-letter', 'App\Http\Controllers\V1\Jobs\ApplicationController@downloadCoverLetter');

    //candidate
    Route::apiResource('/candidate/education', 'App\Http\Controllers\V1\Candidate\EducationController');
    Route::apiResource('/candidate/experience', 'App\Http\Controllers\V1\Candidate\ExperienceController');
    Route::apiResource('/candidate/documents', 'App\Http\Controllers\V1\Candidate\DocumentController');

    //Notifications
    Route::get('/notifications', 'App\Http\Controllers\V1\Notifications\NotificationController@index');
    Route::post('/notifications', 'App\Http\Controllers\V1\Notifications\NotificationController@store');
    Route::put('/notifications/{id}', 'App\Http\Controllers\V1\Notifications\NotificationController@update');
    Route::post('/notifications/delete', 'App\Http\Controllers\V1\Notifications\NotificationController@destroy');

    //Client Portal
    Route::group(['prefix' => 'client'], function () {
        Route::post('/employees', 'App\Http\Controllers\V1\Company\PersonnelController@clientEmployees');
        Route::post('/users', 'App\Http\Controllers\V1\Auth\UserController@clientUsers');
        Route::post('/user-roles', 'App\Http\Controllers\V1\Auth\UserRoleController@clientRoles');
        Route::post('/company-branches', 'App\Http\Controllers\V1\Company\CompanyController@clientCompanyBranches');
        Route::post('/departments', 'App\Http\Controllers\V1\Company\DepartmentController@clientDepartments');
    });
    // });
});
