<table class="x_wrapper" align="center" bgcolor="#EEEEEE" cellpadding="0" cellspacing="0" width="100%">
    <tbody>
        <tr>
            <td style="padding:30px 0">
                <table class="x_row" align="center" bgcolor="#FFFFFF" cellpadding="0" cellspacing="0">
                    <tbody>
                        <tr>
                            <td class="x_spacer" height="40" style="font-size:40px; line-height:40px">&nbsp;</td>
                        </tr>
                        <tr>
                            <th class="x_column" width="640" style="padding-left:30px; padding-right:30px; text-align:left">
                                <a href="https://techsavanna.technology/" target="_blank" rel="noopener noreferrer" data-auth="NotApplicable" style="text-decoration:none">
                                    <img data-imagetype="External" src="https://techsavanna.technology/wp-content/uploads/2018/11/Logo-sav.png" class="x_mobile-center" width="105" alt="Header Logo" style="border:0; width:100%; max-width:105px">
                                </a>
                            </th>
                        </tr>
                        <tr>
                            <td class="x_spacer" height="40" style="font-size:40px; line-height:40px">&nbsp;</td>
                        </tr>
                    </tbody>
                </table>
                <table class="x_row" align="center" bgcolor="#F8F8F8" cellpadding="0" cellspacing="0">
                    <tbody>
                        <tr>
                            <td class="x_spacer" height="80" style="font-size:80px; line-height:80px">&nbsp;</td>
                        </tr>
                        <tr>
                            <th class="x_column x_sans-serif" width="640" style="padding-left:30px; padding-right:30px; font-weight:400; text-align:left">
                                <div class="x_serif" style="color:#1F2225; font-size:28px; font-weight:700; line-height:50px; margin-bottom:30px">Hi <?= $data['user_name'] ?>,</div>
                                <p> Your are receiving this email since you have requested a Verification code, No action is required if you have not requested this service </p>
                                Verification Code: <span data-markjs="true" class="markurdzub1bg" data-ogac="" data-ogab="" data-ogsc="" data-ogsb="" style="background-color: rgb(255, 241, 0); color: '#29abe2';"><?= $data['verification_code'] ?></span></div></b>
                                <br>
                                <br>
                                <b>This verification code will expire in an hour.</b>
                                <div style="color:#969AA1; font-size:13px; margin-top:40px"><strong>DISCLAIMER:</strong> The information contained in or accompanying this e-mail is intended for the use of the stated recipient only. It may contain confidential, proprietary or legally privileged information. No confidentiality or privilege is waived or lost by any mistransmission. If you receive this message in error, please immediately delete it and all copies of it from your system, destroy any hard copies of it and notify <a href="mailto:info@techsavanna.technology?Subject=GHOST%20MAIL" target="_blank" rel="noopener noreferrer" data-auth="NotApplicable" style="color:#969AA1; text-decoration:none">Techsavanna</a>. You must not, directly or indirectly, use, disclose, distribute, print, or copy any part of this message if you are not the intended recipient. Any views or opinions presented herein are solely those of the author and do not necessarily represent those of Techsavanna. </div>
                                <div style="color:#969AA1; font-size:13px; margin-top:40px; text-align:center">This is a computer-generated email. Do not reply to it</div>
                            </th>
                        </tr>
                        <tr>
                            <td class="x_spacer" height="80" style="font-size:80px; line-height:80px">&nbsp;</td>
                        </tr>
                    </tbody>
                </table>
                <table class="x_row" align="center" bgcolor="#1F2225" cellpadding="0" cellspacing="0">
                    <tbody>
                        <tr>
                            <th class="x_column x_has-columns" width="640" style="padding-left:30px; padding-right:30px">

                                <table class="x_row" cellpadding="0" cellspacing="0">
                                    <tbody>
                                        <tr>
                                            <th class="x_column x_mobile-6" width="420" style="padding-right:10px; padding-top:10px; color:#969AA1; font-weight:400; text-align:left">
                                                <div class="x_sans-serif" style="font-size:14px; font-weight:700; margin-bottom:15px">Techsavanna</div>
                                                <div class="x_sans-serif">Reliance Centre, 2nd Floor, Left Wing, Woodvale Grove <br> Westlands, Nairobi Kenya </div>
                                            </th>
                                            <th class="x_column x_mobile-6" width="420" style="padding-left:10px; padding-top:10px; font-weight:400; text-align:left; color:#969AA1">
                                                <div class="x_sans-serif" style="line-height:100%; margin-bottom:15px"><strong>Phone:</strong> +254-722-585375 | +254-722-537792 | +254-700-106077 </div>
                                                <div class="x_sans-serif" style="line-height:100%; margin-bottom:15px"><strong>Email:</strong> <a href="mailto:info@techsavanna.technology?Subject=PERSONAL%20INQUIRY" target="_blank" rel="noopener noreferrer" data-auth="NotApplicable" style="color:#969AA1; text-decoration:none">info@techsavanna.technology</a> </div>
                                                <div class="x_sans-serif" style="line-height:100%"><strong>Website:</strong> <a href="https://www.techsavanna.technology/" target="_blank" rel="noopener noreferrer" data-auth="NotApplicable" style="color:#969AA1; text-decoration:none">www.techsavanna.technology</a> </div>
                                            </th>
                                        </tr>
                                    </tbody>
                                </table>
                                <div class="x_spacer" style="font-size:40px; line-height:40px">&nbsp;</div>
                                <table class="x_row" cellpadding="0" cellspacing="0">
                                    <tbody>
                                        <tr>
                                            <th class="x_column" width="640" style="color:#969AA1; font-weight:400; text-align:left">
                                                <div class="x_sans-serif">Copyright © <?= date("Y") ?> <a href="https://www.techsavanna.technology/" target="_blank" rel="noopener noreferrer" data-auth="NotApplicable" style="color:#969AA1; text-decoration:none">Techsavanna</a>. All Rights Reserved.</div>
                                            </th>
                                        </tr>
                                        <tr>
                                            <td class="x_spacer" height="30" style="font-size:30px; line-height:30px">&nbsp;</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </th>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>