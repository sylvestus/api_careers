<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="robots" content="noindex,nofollow" />
<meta name="viewport" content="width=device-width; initial-scale=1.0;" />
<style type="text/css">
    @import url(https://fonts.googleapis.com/css?family=Open+Sans:400,700);

    body {
        margin: 0;
        padding: 0;
        background: #e1e1e1;
    }

    div,
    p,
    a,
    li,
    td {
        -webkit-text-size-adjust: none;
    }

    .ReadMsgBody {
        width: 100%;
        background-color: #ffffff;
    }

    .ExternalClass {
        width: 100%;
        background-color: #ffffff;
    }

    body {
        width: 100%;
        height: 100%;
        background-color: #e1e1e1;
        margin: 0;
        padding: 0;
        -webkit-font-smoothing: antialiased;
    }

    html {
        width: 100%;
    }

    p {
        padding: 0 !important;
        margin-top: 0 !important;
        margin-right: 0 !important;
        margin-bottom: 0 !important;
        margin-left: 0 !important;
    }

    .visibleMobile {
        display: none;
    }

    .hiddenMobile {
        display: block;
    }

    @media only screen and (max-width: 600px) {
        body {
            width: auto !important;
        }

        table[class=fullTable] {
            width: 96% !important;
            clear: both;
        }

        table[class=fullPadding] {
            width: 85% !important;
            clear: both;
        }

        table[class=col] {
            width: 45% !important;
        }

        .erase {
            display: none;
        }
    }

    @media only screen and (max-width: 420px) {
        table[class=fullTable] {
            width: 100% !important;
            clear: both;
        }

        table[class=fullPadding] {
            width: 85% !important;
            clear: both;
        }

        table[class=col] {
            width: 100% !important;
            clear: both;
        }

        table[class=col] td {
            text-align: left !important;
        }

        .erase {
            display: none;
            font-size: 0;
            max-height: 0;
            line-height: 0;
            padding: 0;
        }

        .visibleMobile {
            display: block !important;
        }

        .hiddenMobile {
            display: none !important;
        }
    }
</style>

<table border="0" cellpadding="0" cellspacing="0">
    <tr>
        <td>
            <table border="0" cellpadding="0" cellspacing="0">
                <tbody>
                    <tr>
                        <td style="font-size: 12px; color: #5b5b5b; font-family: 'Avenir', sans-serif; line-height: 18px; vertical-align: top; border-bottom:1px solid #e4e4e4">
                            <br />
                            <small><b>Name:</b> {{$data['first_name'] ." ". $data['last_name']}}</small><br />
                            <small><b>Phone:</b> {{$data['phone']}}</small><br />
                            <small><b>Email:</b> {{$data['email']}}</small><br />
                            <small><b>Country:</b> {{$data['country']}}</small><br />
                            <small><b>Gender:</b> {{$data['gender']}}</small><br />
                            <small><b>Date Of Birth:</b> {{ date("d/m/Y", strtotime($data['date_of_birth']))}}</small><br />
                            <small><b>Experience:</b> {{$data['experience']}}</small><br />
                            <small><b>Availability:</b> {{$data['availability']}}</small><br />
                        </td>
                    </tr>
                    <tr>
                        <td style="font-size: 12px; color: #5b5b5b; font-family: 'Avenir', sans-serif; line-height: 18px; vertical-align: top; border-bottom:1px solid #e4e4e4">
                            <h6>Summary</h6>
                        </td>
                    </tr>
                    <tr>
                        <td style="font-size: 12px; color: #5b5b5b; font-family: 'Avenir', sans-serif; line-height: 18px; vertical-align: top; border-bottom:1px solid #e4e4e4">
                            <small>{{$data['summary']}}</small>
                        </td>
                    </tr>
                    @foreach ($data['education'] as $education)
                    <tr>
                        <td>
                            <br />
                            <small><b>{{ $education['institution'] }}</b></small>
                            <small>{{ date("d/m/Y", strtotime($education['start_date'])) ." - ". date("d/m/Y", strtotime($education['end_date'])) }}</small><br />
                            <small><b>Course: </b>{{ $education['course'] }}</small>
                            <small><b>Grade:</b> {{ $education['grade'] }}</small>
                        </td>
                    </tr>
                    @endforeach
                    <tr>
                        <td style="font-size: 12px; color: #5b5b5b; font-family: 'Avenir', sans-serif; line-height: 18px; vertical-align: top; border-bottom:1px solid #e4e4e4">
                            <h6>Experience</h6>
                        </td>
                    </tr>
                    @foreach ($data['work_experience'] as $experience)
                    <tr>
                        <td>
                            <br />
                            <small><b>{{ $experience['employer'] }}</b></small>
                            <small>{{ date("d/m/Y", strtotime($experience['start_date'])) ." - ". date("d/m/Y", strtotime($experience['end_date'])) }}</small><br />
                            <small>{{ $experience['job_title'] }}</small>
                        </td>
                    </tr>
                    @endforeach
                    <tr>
                        <td style="font-size: 12px; color: #5b5b5b; font-family: 'Avenir', sans-serif; line-height: 18px; vertical-align: top; border-bottom:1px solid #e4e4e4">
                            <h6>Skills</h6>
                        </td>
                    </tr>
                    @foreach ($data['skills'] as $skill)
                    <tr>
                        <td>
                            <small>{{ $skill['skill'] }}</small>
                        </td>
                    </tr>
                    @endforeach
                    <tr>
                        <td style="font-size: 12px; color: #5b5b5b; font-family: 'Avenir', sans-serif; line-height: 18px; vertical-align: top; border-bottom:1px solid #e4e4e4">
                            <h6>Rreferees</h6>
                        </td>
                    </tr>
                    @foreach ($data['referees'] as $referee)
                    <tr>
                        <td>
                            <small>{{ $referee['title'] }}</small>
                            <small>{{ $referee['name'] }}</small>
                            <small>{{ $referee['phone'] }}</small>
                            <small>{{ $referee['email'] }}</small>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </td>
    </tr>
</table>