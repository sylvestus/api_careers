<?php

namespace App\Http\Resources\V1\Auth;

use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\URL;

class UsersResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            "id" => $this->id,
            "company_id" => $this->company_id,
            "name" => $this->name,
            "email" => $this->email,
            "phone" => $this->phone,
            "profile_photo"=>isset($this->profile_photo) ? URL::to('/') . '/api/v1/profile-photo/' . $this->id : null,
            "login_attempts" => $this->login_attempts,
            "role_id" => $this->role_id,
            "role" =>isset( $this->role->title) ?  $this->role->title : null,
            "auth_code" => $this->auth_code,
            "created_at" => $this->created_at,
            "updated_at" => $this->updated_at,
            "company" => $this->company
        ];
    }
}