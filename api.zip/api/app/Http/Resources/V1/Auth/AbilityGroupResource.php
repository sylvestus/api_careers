<?php

namespace App\Http\Resources\V1\Auth;

use Illuminate\Http\Resources\Json\JsonResource;

class AbilityGroupResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'group_id' => $this->id,
            'title' => $this->title,
            'label' => $this->title,
            'description' => $this->description,
            'children' => AbilityResource::collection($this->abilities),
        ];
    }
}
