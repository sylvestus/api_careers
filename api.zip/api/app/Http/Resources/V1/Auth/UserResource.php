<?php

namespace App\Http\Resources\V1\Auth;

use App\Models\V1\Billing\Plan;
use App\Models\V1\Billing\PlanFeature;
use App\Models\V1\Billing\Subscription;
use App\Models\V1\Company\Personnel;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\URL;

class UserResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            "id" => $this->id,
            "company_id" => $this->company_id,
            "name" => $this->name,
            "email" => $this->email,
            "phone" => $this->phone,
            "access_token" => $this->access_token ? $this->access_token : auth()->user()->createToken('my-app-token')->plainTextToken,
            "profile_photo" => isset($this->profile_photo) ? URL::to('/') . '/api/v1/profile-photo/' . $this->id : null,
            "login_attempts" => $this->login_attempts,
            "role_id" => $this->role_id,
            "role" => isset($this->role->title) ?  $this->role->title : null,
            "auth_code" => $this->auth_code,
            "created_at" => $this->created_at,
            "updated_at" => $this->updated_at,
            "profile" => Personnel::find($this->id),
            "company_logo"  => isset($this->company->company_logo) ? URL::to('/') . '/logos/' . $this->company->company_logo : null,
            "company" => $this->company, "groups" => DB::table('roles_ability')
                ->select('ability_groups.title')
                ->join('ability', 'ability.id', '=', 'roles_ability.ability_id')
                ->join('ability_groups', 'ability_groups.id', '=', 'ability.group_id')
                ->where('roles_ability.role_id', '=', $this->role_id)
                ->groupBy('ability_groups.title')
                ->get()->pluck('title'),
            "abilities" => isset($this->role->abilities) ? $this->role->abilities->pluck('title') : [],
        ];
    }
}
