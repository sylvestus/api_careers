<?php

namespace App\Http\Resources\V1\Auth;

use Illuminate\Http\Resources\Json\JsonResource;

class AuditLogResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            "id" => $this->id,
            "user" => isset($this->user) ? $this->user->name : null,
            "ip" => $this->ip,
            "browser" => self::getBrowser($this->user_agent),
            "platform" => self::getPlatform($this->user_agent),
            "url" => $this->url,
            "method" => $this->method,
            "request" => $this->request,
            "response" => $this->response,
            "created_at" => $this->created_at,
            "updated_at" => $this->updated_at
        ];
    }

    static function getPlatform($user_agent)
    {
        $platform = 'Unknown';

        //First get the platform?
        if (preg_match('/linux/i', $user_agent)) {
            $platform = 'Linux';
        } elseif (preg_match('/macintosh|mac os x/i', $user_agent)) {
            $platform = 'Apple';
        } elseif (preg_match('/windows|win32/i', $user_agent)) {
            $platform = 'Windows';
        }

        return $platform;
    }

    static function getBrowser($user_agent)
    {
        $browser = 'Unknown';
        // Get the name of the useragent
        if (preg_match('/MSIE/i', $user_agent) && !preg_match('/Opera/i', $user_agent)) {
            $browser = 'Internet Explorer';
        } elseif (preg_match('/Firefox/i', $user_agent)) {
            $browser = 'Mozilla Firefox';
        } elseif (preg_match('/Chrome/i', $user_agent)) {
            $browser = 'Google Chrome';
        } elseif (preg_match('/Safari/i', $user_agent)) {
            $browser = 'Apple Safari';
        } elseif (preg_match('/Opera/i', $user_agent)) {
            $browser = 'Opera';
        } elseif (preg_match('/Netscape/i', $user_agent)) {
            $browser = 'Netscape';
        }

        return $browser;
    }
}
