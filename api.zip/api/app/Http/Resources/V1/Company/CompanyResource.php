<?php

namespace App\Http\Resources\V1\Company;

use App\Models\V1\Company\JobTitle;
use App\Models\V1\Company\Personnel;
use App\Models\V1\Job\Application;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\URL;

class CompanyResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return array_merge(parent::toArray($request), [
            "company_logo"  => isset($this->company_logo) ? URL::to('/') . '/logos/' . $this->company_logo : null,
            "jobs" => JobTitle::where(['company_id' => $this->id])->count(),
            "applications" => Application::whereHas('job_title', function ($q) {
                $q->where('company_id', '=', $this->id);
            })->count(),
            "hired" => Personnel::where(['company_id' => $this->id])->count(),
        ]);
    }
}
