<?php

namespace App\Http\Resources\V1\Company;

use App\Models\V1\Company\Personnel;
use Illuminate\Http\Resources\Json\JsonResource;

class DepartmentResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return array_merge(parent::toArray($request), [
            "employee_count" => Personnel::where(['department_id'=>$this->id, 'status'=>'Active'])->count(),
            "hod_name"  => $this->hod ? $this->personnel->first_name." ".$this->personnel->last_name : null,
        ]);
    }
}
