<?php

namespace App\Http\Resources\V1\Company;

use App\Http\Resources\V1\Jobs\DocumentsResource;
use App\Models\V1\Auth\User;
use App\Models\V1\Candidate\Document;
use App\Models\V1\Candidate\Education;
use App\Models\V1\Candidate\Experience;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\URL;

class PersonnelResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $user = User::find($this->id);
        $education = Education::where(['user_id' => $user->id])->get();
        $experience = Experience::where(['user_id' => $user->id])->get();
        $documents = Document::where(['user_id' => $user->id])->get();

        $percent = 0;

        if ($this->first_name && $this->last_name && $this->email && $this->phone) {
            $percent = 25;
        }
        if ($this->first_name && $this->last_name && $this->email && $this->phone && $this->gender && $this->date_of_birth) {
            $percent = 50;
        }
        if ($this->first_name && $this->last_name && $this->email && $this->phone && $this->gender && $this->date_of_birth && $this->experience && $this->availability && $this->highest_qualification) {
            $percent = 75;
        }
        if ($this->first_name && $this->last_name && $this->email && $this->phone && $this->gender && $this->date_of_birth && $this->experience && $this->availability && $this->highest_qualification && !$education->isEmpty() && !$experience->isEmpty()) {
            $percent = 90;
        }
        if ($this->first_name && $this->last_name && $this->email && $this->phone && $this->gender && $this->date_of_birth && $this->experience && $this->availability && $this->highest_qualification && !$education->isEmpty() && !$experience->isEmpty() && !$documents->isEmpty()) {
            $percent = 100;
        }

        return array_merge(parent::toArray($request), [
            "profile_photo" => isset($user->profile_photo) ? URL::to('/') . '/api/v1/profile-photo/' . $this->id : null,
            "full_name"  => $this->first_name . " " . $this->middle_name . " " . $this->last_name,
            "department"  => $this->department_id ? $this->department->department : null,
            "employment_type"  => $this->employment_type_id ? $this->employment_type->employment_type : null,
            "job_title"  => $this->job_title_id ? $this->job_title->job_title : null,
            "work_station"  => $this->work_station_id ? $this->work_station->company_name : null,
            "bank_name"  => $this->bank_id ? $this->bank->bankname : null,
            "education" => $education,
            "work_experience" => $experience,
            "summary" => $this->summary,
            "skills" => [],
            "referees" => [],
            "documents" => DocumentsResource::collection($documents),
            "percentage" => $percent,
            "uploaded_cv" => Document::where(['user_id' => $this->id, 'document_type' => 'Curriculum Vitae'])->count() > 0 ? true : false,
        ]);
    }
}
