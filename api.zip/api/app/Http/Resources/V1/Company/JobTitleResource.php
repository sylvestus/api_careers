<?php

namespace App\Http\Resources\V1\Company;

use App\Models\V1\Job\Application;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Facades\URL;

class JobTitleResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return array_merge(parent::toArray($request), [
            "client"=>$this->company->company_name,
            "company_logo"  => isset($this->company->company_logo) ? URL::to('/') . '/logos/' . $this->company->company_logo : "/assets/img/logo.png",
            "applied" => isset(Auth::user()->id) ? (Application::where(['job_id'=>$this->id, 'user_id'=>Auth::user()->id])->count()>0 ? true : false) : false,
            "applications" => Application::where(['job_id'=>$this->id])->count(),
            "status"=> Carbon::now()->startOfDay()->gte($this->application_deadline) ? "Inactive" : "Active",
            "interviewed" => Application::where(['job_id'=>$this->id, 'status'=>'Interviewed'])->count(),
            "shortlisted" => Application::where(['job_id'=>$this->id, 'status'=>'Shortlisted'])->count(),
            "hired" => Application::where(['job_id'=>$this->id, 'status'=>'Hired'])->count(),
        ]);
    }
}
