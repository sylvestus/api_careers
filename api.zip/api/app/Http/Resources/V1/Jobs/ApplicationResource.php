<?php

namespace App\Http\Resources\V1\Jobs;

use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\URL;
use App\Models\V1\Auth\User;

class ApplicationResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $user = User::find($this->user_id);
        return array_merge(parent::toArray($request), [
            "profile_photo" => isset($user->profile_photo) ? URL::to('/') . '/api/v1/profile-photo/' . $this->id : null,
            "applicant"  => $this->personnel->first_name." ".$this->personnel->last_name,
            "position"  => $this->job_title->job_title,
            "job_type"  => $this->job_title->job_type,
            "client"  => $this->job_title->company->company_name,
            "application_histories"  => $this->application_histories,
            "application_interviews"  => $this->application_interviews
        ]);
    }
}
