<?php

namespace App\Http\Resources\V1\Notifications;

use App\Models\V1\Auth\User;
use Illuminate\Support\Facades\URL;

use Illuminate\Http\Resources\Json\JsonResource;

class NotificationResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $user = User::find($this->user_id);
        return array_merge(parent::toArray($request), [
            'sender' => $this->user->name,
            "profile_photo" => isset($user->profile_photo) ? URL::to('/') . '/api/v1/profile-photo/' . $this->user_id : null,
        ]);
    }
}
