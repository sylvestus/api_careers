<?php

namespace App\Http\Middleware;

use App\Models\V1\Auth\AuditLog;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class LogAudit
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        $response = $next($request);

        if (app()->environment('local')) {
            $log = [
                'company_id' => $request->user()->company_id,
                'user_id' => $request->user()->id,
                'ip' => $request->getClientIp(),
                'url' => $request->getUri(),
                'user_agent' => $request->server('HTTP_USER_AGENT'),
                'method' => $request->getMethod(),
                'request' => $request->getContent(),
                'response' => $response->getContent()
            ];
            if ($request->getMethod() == 'DELETE' || $request->getMethod() == 'PUT') {
                AuditLog::create($log);
            }
            Log::info($log);
        }

        return $response;
    }
}
