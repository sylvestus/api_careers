<?php

namespace App\Http\Controllers\V1\Definitions;

use App\Http\Controllers\Controller;
use App\Models\V1\Definitions\Country;
use App\Models\V1\Definitions\Industry;

class DefinitionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function country()
    {
        return response()->json(["data" => Country::orderBy('name', 'asc')->get()], 200);
    }
    public function industry()
    {
        return response()->json(["data" => Industry::orderBy('industry', 'asc')->get()], 200);
    }
}
