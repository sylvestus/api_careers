<?php

namespace App\Http\Controllers\V1\Company;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\Company\DepartmentResource;
use App\Models\V1\Company\Department;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DepartmentController extends Controller
{
    /**
     * Display a listing of the departments
     * 
     * list all departments registered
     * 
     * @group Company management
     * @authenticated
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return DepartmentResource::collection(Department::orderBy('id', 'DESC')->get());
    }
    public function clientDepartments(Request $request)
    {
        return DepartmentResource::collection(Department::where(['company_id' => Auth::user()->company_id])->orderBy('id', 'DESC')->get());
    }
    /**
     * Store a newly created department in storage.
     *
     * @group Company management
     * @authenticated
     * 
     * @bodyParam company_id int required The company's id. Example: 1
     * @bodyParam department string required The department name.
     * @bodyParam description longtext required The department description. Example: Deparment of Development
     * @bodyParam status string required The department status. No-example
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();
        $data['company_id'] = Auth::user()->company_id;
        Department::create($data);
        return response(["message" => "Department has been created successfully"], 200);
    }
    /**
     * Update the specified department in storage.
     *
     * @group Company management
     * @authenticated
     * 
     * @bodyParam company_id int required The company's id. Example: 1
     * @bodyParam department string required The department name.
     * @bodyParam description longtext required The department description. Example: Deparment of Development
     * @bodyParam status string required The department status. No-example
     * Update the specified resource in storage.
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $record = Department::find($id);
        if ($record) {
            $record->update($request->all());
            return response(["message" => "Department has been updated"], 200);
        } else {
            return response(["message" => "Record not found"], 404);
        }
    }
    public function destroy($id)
    {
        $record = Department::find($id);
        if ($record) {
            $record->delete();
            return response(["message" => "Department has been deleted"], 200);
        } else {
            return response(["message" => "Record not found"], 404);
        }
    }
}
