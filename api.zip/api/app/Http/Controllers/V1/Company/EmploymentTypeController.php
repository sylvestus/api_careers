<?php

namespace App\Http\Controllers\V1\Company;

use App\Http\Controllers\Controller;
use App\Models\V1\Company\EmploymentType;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class EmploymentTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return response()->json(["data" => EmploymentType::orderBy('id', 'DESC')->get()], 200);
    }
    
    public function clientEmploymentTypes(Request $request)
    {
        return response()->json(["data" => EmploymentType::orderBy('id', 'DESC')->get()], 200);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();
        $data['company_id'] = Auth::user()->company_id;
        EmploymentType::create($data);
        return response(["message" => "Employment type has been created successfully"],200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $record = EmploymentType::find($id);
        if($record)
        {
            $record->update($request->all());
            return response(["message" => "Employment type has been updated"],200);
        } else {
            return response(["message" => "Record not found"],404);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $record = EmploymentType::find($id);
        if ($record) {
            $record->delete();
            return response(["message" => "Employment type has been deleted"], 200);
        } else {
            return response(["message" => "Record not found"], 404);
        }
    }
}
