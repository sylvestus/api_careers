<?php

namespace App\Http\Controllers\V1\Company;

use App\Http\Controllers\Controller;
use App\Http\Requests\V1\Company\PersonnelRequest;
use App\Http\Resources\V1\Company\PersonnelResource;
use App\Models\V1\Company\Personnel;
use App\Models\V1\Auth\User;
use App\Models\V1\Company\UsersImport;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Str;
use App\Models\V1\Billing\Subscription;
use Illuminate\Support\Facades\Auth;

class PersonnelController extends Controller
{
    /**
     * Display a listing of the company
     * 
     * list all personnel registered
     * 
     * @group Company management
     * @authenticated
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return PersonnelResource::collection(Personnel::orderBy('company_id', 'asc')->get());
    }
    /**
     * Display a listing of the employee data
     * 
     * @group Client data
     * @authenticated
     *
     * @return \Illuminate\Http\Response
     */
    public function clientEmployees(Request $request)
    {
        return PersonnelResource::collection(Personnel::where(['company_id' => Auth::user()->company_id])->orderBy('id', 'DESC')->get());
    }
    /**
     * Store a newly created personnel in storage.
     *
     * @group Company management
     * @authenticated
     * 
     * @bodyParam company_id int required The company's id. Example: 1
     * @bodyParam id_number int required The personnel's id number.
     * @bodyParam kra_pin char required The kra-pin number. Example: A9*******7P
     * @bodyParam date_of_birth timestamps required Then date of birth. No-example
     * @bodyParam full_name string required The personnel's full name. Example: John Doe 
     * @bodyParam email string required The personnel's email address
     * @bodyParam phone string. required The personnels phone number. No-example
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(PersonnelRequest $request)
    {
        $accounts = Personnel::where(['company_id' => Auth::user()->company_id])->count();
        $plan = Subscription::with('plan')->where(['company_id' => Auth::user()->company_id])->orderBy('id', 'DESC')->first();

        if ($accounts > 3 && $plan->plan_id == 1) {
            return response(["message" => "You have reached the maximum limit in your current plan. Work is fun when done together. Upgrade and on-board your team now!"], 201);
        } else {
            $data = $request->all();
            $data['company_id'] = Auth::user()->company_id;

            $pass =  Str::random(8);
            $data['name'] = $request->first_name . " " . $request->last_name;
            $data['email'] = $request->email;
            $data['username'] = $request->email;
            $data['login_attempts'] = 10;
            $data['role_id'] = 2;
            $data['phone'] = $request->phone;
            $data['company_id'] = Auth::user()->company_id;
            $data['password'] = bcrypt($pass);
            $user = User::create($data);
            $data['id'] = $user->id;

            if (Personnel::create($data)) {
                $this->sendRegistrationEmail(['name' => $data['name'], 'email' => $request->email, 'company_name' => $request->company_name, 'password' => $pass, 'reset_url' => 'https://https://careers.techsavanna.technology/login']);
                return response(["message" => "Record has been created successfully"], 200);
            } else {
                return response(["message" => "Record creation failed"], 201);
            }
        }
    }

    /**
     * Display the specified personnels.
     * 
     * Show the details of the specific personnels.
     * 
     * @group Company management
     * @authenticated     
     * 
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return new PersonnelResource(Personnel::findOrFail($id));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }
    /**
     * Update the specified personnel in storage.
     *
     * @group Company management
     * @authenticated
     * 
     * @bodyParam company_id int required The company's id. Example: 1
     * @bodyParam id_number int required The personnel's id number.
     * @bodyParam kra_pin char required The kra-pin number. Example: A9*******7P
     * @bodyParam date_of_birth timestamps required Then date of birth. No-example
     * @bodyParam full_name string required The personnel's full name. Example: John Doe 
     * @bodyParam email string required The personnel's email address
     * @bodyParam phone string. required The personnels phone number. No-example
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $personnel = Personnel::find($id);
        if ($personnel) {
            $personnel->update($request->all());
            return response(["message" => "Record has been updated"], 200);
        } else {
            return response(["message" => "Record not found"], 404);
        }
    }
    /**
     * Store a newly created personnel in storage(Excel pload).
     *
     * @group Company management
     * @authenticated
     */
    public function upload($company_id, Request $request)
    {
        $accounts = Personnel::where(['company_id' => $company_id])->count();
        $plan = Subscription::with('plan')->where(['company_id' => $company_id])->orderBy('id', 'DESC')->first();

        if ($accounts > 3 && $plan->plan_id == 1) {
            return response(["message" => "You have reached the maximum limit in your current plan. Work is fun when done together. Upgrade and on-board your team now!"], 201);
        } else {
            if ($request->file('file')) {
                if (Excel::import(new UsersImport($company_id), $request->file('file'))) {
                    return response(["message" => "Batch employee profiles uploaded"], 200);
                } else {
                    return response(["message" => "Batch employee profiles upload failed"], 200);
                }
            } else {
                return response(["message" => "Batch employee profiles upload failed"], 200);
            }
        }
    }
    /**
     * Remove the specified personnel from storage.
     *
     * @group Company management
     * @authenticated
     * 
     * @bodyParam id int required The id of the user. Example: 1
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Personnel::find($id)->delete();
        return response(["message" => "Record has been deleted"], 200);
    }
    public function sendRegistrationEmail($user)
    {
        $data = [
            'user_name' => $user['name'],
            'user_email' => $user['email'],
            'company_name' => $user['company_name'],
            'password' => $user['password'],
            'reset_url' => $user['reset_url'],
        ];
        $this->sendTo = $user['email'];

        $result = Mail::send(['html' => view('emails.welcome', ['data' => $data])], $data, function ($message) {
            $message->subject('Welcome On Board');
            $message->to($this->sendTo);
        });
        return $result;
    }
}
