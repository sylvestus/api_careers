<?php

namespace App\Http\Controllers\V1\Company;

use App\Http\Controllers\Controller;
use App\Http\Controllers\V1\Gateways\MpesaController;
use App\Http\Requests\V1\Company\CompanyRequest;
use App\Http\Resources\V1\Company\CompanyResource;
use App\Http\Resources\V1\Company\CompanyWalletResource;
use App\Http\Resources\V1\Payment\TransactionsResource;
use App\Models\V1\Auth\User;
use App\Models\V1\Company\Company;
use App\Models\V1\Company\CompanyWallet;
use App\Models\V1\Company\Personnel;
use App\Models\V1\Gateway\MpesaTrial;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Auth;

class CompanyController extends Controller
{
    /**
     * Display listing of the company
     * 
     * list all companies registered
     * 
     * @group Company management
     * @authenticated
     *
     * @return \Illuminate\Http\Response
     */

    public function index()
    {
        return CompanyResource::collection(Company::orderBy('id', 'DESC')->get());
    }
    public function clientCompanyBranches(Request $request)
    {
        return CompanyResource::collection(Company::where(['id' => Auth::user()->company_id])->orWhere(['parent_id' => Auth::user()->company_id])->orderBy('id', 'DESC')->get());
    }
    /**
     * Store a newly created company in storage.
     * 
     * @group Company management
     * @authenticated
     * 
     * @bodyParam company_name string required The name of the company. Example: abc ltd
     * @bodyParam merchant_code char The marchant code.
     * @bodyParam business_regno string required The business registration number. Example: R/W/4597?G
     * @bodyParam kra_pin string This won't be added to the examples. No-example
     * @bodyParam email int required The companies/managein director's email. Example: email@mail.com     * 
     * @bodyParam phone string The company's phone number
     * @bodyParam company_size string. No-example
     * @bodyParam industry string. No-example
     * @bodyParam physical_ address sring
     * @bodyParam room_countryid int The id of the room.
     * 
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(CompanyRequest $request)
    {
        $data = $request->all();
        $data['merchant_code'] = generateRandomString();
        $data['parent_id'] = Auth::user()->company_id;
        Company::create($data);
        return response(["message" => "Company has been created"], 200);
    }
    public function uploadLogo(Request $request, $id)
    {
        $record = Company::find($id);
        if ($record) {
            if ($request->file('file')) {
                if ($record->company_logo) {
                    File::delete(public_path('logos/' . $record->company_logo));
                }
                $file = $request->file('file');
                $filename = Str::uuid()->toString() . "." . $request->file->extension();
                $file->move(public_path('logos'), $filename);
                $record->update(['company_logo' => $filename]);
                return response(["message" => "Company logo has been uploaded"], 200);
            } else {
                return response(["message" => "Company logo upload failed. Please try again"], 200);
            }
        } else {
            return response(["message" => "Record not found"], 404);
        }
    }
    /**
     * Update the specified company in storage.
     *
     * @group Company management
     * @authenticated
     * 
     * @bodyParam company_name string required The name of the company. Example: abc ltd
     * @bodyParam merchant_code char The marchant code.
     * @bodyParam business_regno string required The business registration number. Example: R/W/4597?G
     * @bodyParam kra_pin string This won't be added to the examples. No-example
     * @bodyParam email int required The companies/managein director's email. Example: email@mail.com     * 
     * @bodyParam phone string The company's phone number
     * @bodyParam company_size string. No-example
     * @bodyParam industry string. No-example
     * @bodyParam physical_ address sring
     * @bodyParam room_countryid int The id of the room.
     * 
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $company = Company::find($id);
        if ($company) {
            $company->update($request->all());
            return response(["message" => "Company information has been updated"], 200);
        } else {
            return response(["message" => "Company profile not found"], 404);
        }
    }

    /**
     * Remove the specified company from storage.
     *
     * @group Company management
     * @authenticated
     * 
     * @bodyParam id int required The id of the user. Example: 1
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $record = Company::find($id);
        if ($record) {
            $record->delete();
            return response(["message" => "Company has been deleted"], 200);
        } else {
            return response(["message" => "Record not found"], 404);
        }
    }
}
