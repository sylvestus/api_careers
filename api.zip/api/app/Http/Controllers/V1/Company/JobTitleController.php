<?php

namespace App\Http\Controllers\V1\Company;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\Company\JobTitleResource;
use App\Models\V1\Company\JobTitle;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\V1\Definitions\Notify;
use App\Models\V1\Auth\User;
use Carbon\Carbon;

class JobTitleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return JobTitleResource::collection(JobTitle::orderBy('id', 'DESC')->get());
    }

    public function clientJobTitles(Request $request)
    {
        $size = $request->size ? $request->size : 10;
        if ($request->search) {
            return JobTitleResource::collection(JobTitle::where('job_title', 'like', '%' . $request->search . '%')->whereDate('application_deadLine', '>=', Carbon::now())->orderBy('id', 'DESC')->paginate($size));
        } else {
            if ($request->filter) {
                return JobTitleResource::collection(JobTitle::where($request->filter)->whereDate('application_deadLine', '>=', Carbon::now())->orderBy('id', 'DESC')->paginate($size));
            } else {
                return JobTitleResource::collection(JobTitle::whereDate('application_deadLine', '>=', Carbon::now())->orderBy('id', 'DESC')->paginate($size));
            }
        }
    }

    public function getAllJobs(Request $request)
    {
        $size = $request->size ? $request->size : 10;
        if ($request->company_id) {
            return JobTitleResource::collection(JobTitle::where(['company_id' => $request->company_id])->paginate($size));
        } else {
            return JobTitleResource::collection(JobTitle::paginate($size));
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $position = $request->job_title;
        $data = $request->all();
        $data['application_deadline'] = Carbon::parse($request->application_deadline)->endOfDay()->toDateTimeString();

        JobTitle::create($data);
        foreach (User::where(['role_id' => 2])->get() as $candidate) {
            (new Notify())->sendEmail($candidate['email'], 'New Job Alert', ['position' => $position, 'name' => $candidate['name']], 'jobs.new_job_alert', null);
        }
        return response(["message" => "Job title has been created successfully"], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $record = JobTitle::find($id);
        if ($record) {
            $record->update($request->all());
            return response(["message" => "Job title has been updated"], 200);
        } else {
            return response(["message" => "Record not found"], 404);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $record = JobTitle::find($id);
        if ($record) {
            $record->delete();
            return response(["message" => "Job title has been deleted"], 200);
        } else {
            return response(["message" => "Record not found"], 404);
        }
    }
}
