<?php

namespace App\Http\Controllers\V1\Candidate;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\V1\Candidate\Experience;
use Illuminate\Support\Facades\Auth;

class ExperienceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();
        $data['user_id'] = Auth::user()->id;
        Experience::create($data);
        return response(["message" => "Experience has been created successfully"],200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $record = Experience::find($id);
        if($record)
        {
            $record->update($request->all());
            return response(["message" => "Experience has been updated"],200);
        } else {
            return response(["message" => "Record not found"],404);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $record = Experience::find($id);
        if ($record) {
            $record->delete();
            return response(["message" => "Experience has been deleted"], 200);
        } else {
            return response(["message" => "Record not found"], 404);
        }
    }
}
