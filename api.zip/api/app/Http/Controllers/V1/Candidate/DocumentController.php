<?php

namespace App\Http\Controllers\V1\Candidate;

use App\Http\Controllers\Controller;
use App\Models\V1\Candidate\Document;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;

class DocumentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if ($file = $request->file('file')) {
            $filename = Str::uuid()->toString() . "." . $request->file->extension();
            $filesize = $request->file->getSize();
            $filetype = $request->file->extension();
            $file->move(public_path('documents'), $filename);
            Document::create(['company_id' => isset(Auth::user()->company_id) ? Auth::user()->company_id : null, 'document_type' => $request->document_type, 'document_title' => $request->document_title, 'user_id' => Auth::user()->id, 'filename' => $filename, 'filesize' => $filesize, 'filetype' => $filetype]);
            return response(["message" => "Document has been uploaded"], 200);
        } else {
            return response(["message" => "Document upload failed. Please try again"], 200);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $record = Document::find($id);
        if ($record) {
            $record->update($request->all());
            return response(["message" => "Document has been updated"], 200);
        } else {
            return response(["message" => "Record not found"], 404);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $record = Document::find($id);
        if ($record) {
            $record->delete();
            return response(["message" => "Document has been deleted"], 200);
        } else {
            return response(["message" => "Record not found"], 404);
        }
    }
}
