<?php

namespace App\Http\Controllers\V1\Jobs;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\Jobs\ApplicationResource;
use App\Models\V1\Job\Application;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Resources\V1\Company\JobTitleResource;
use App\Models\V1\Company\EmploymentType;
use App\Models\V1\Company\JobTitle;
use App\Models\V1\Company\Personnel;
use App\Models\V1\Definitions\Notify;
use App\Models\V1\Job\ApplicationHistory;
use App\Models\V1\Job\ApplicationInterview;
use Carbon\Carbon;
use PDF;

class ApplicationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function dashboard()
    {
        return response(["data" => ['jobs' => JobTitle::whereDate('application_deadline', '>', Carbon::now())->count(), 'applied' => Application::count(), 'shortlisted' => Application::where(['status' => 'Shortlisted'])->count(), 'interviewed' => Application::where(['status' => 'Interviewed'])->count(), 'applications' => ApplicationResource::collection(Application::limit(5)->get())]], 200);
    }
    public function index()
    {
        return ApplicationResource::collection(Application::orderBy('id', 'asc')->get());
    }
    public function filter(Request $request, Application $application)
    {
        $size = $request->size ? $request->size : 10;
        if ($request->company_id || $request->job_id) {
            $company_id = $request->company_id;
            if ($request->company_id && $request->job_id) {
                $data = $application->whereHas('job_title', function ($q) use ($company_id) {
                    $q->where('company_id', '=', $company_id);
                })->where(['job_id' => $request->job_id])->orderBy('id', 'asc')->paginate($size);
            } elseif (!$request->company_id && $request->job_id) {
                $data = $application->where(['job_id' => $request->job_id])->orderBy('id', 'asc')->paginate($size);
            } else {
                $data = $application->whereHas('job_title', function ($q) use ($company_id) {
                    $q->where('company_id', '=', $company_id);
                })->orderBy('id', 'asc')->paginate($size);
            }

            return ApplicationResource::collection($data);
        } else {
            return ApplicationResource::collection($application->orderBy('id', 'asc')->paginate($size));
        }
    }
    public function applications()
    {
        return JobTitleResource::collection(JobTitle::whereHas('applications', function ($query) {
            $query->where('user_id', '=', Auth::user()->id);
        })->orderBy('id', 'DESC')->get());
    }
    public function downloadCv(Request $request)
    {
        PDF::AddPage('P', 'A4');
        $this->filepath = storage_path('cvs/' . $request->first_name . " " . $request->last_name . "cv.pdf");

        $view = \View::make('jobs.cv', ['data' => $request->all()]);
        $html = $view->render();

        PDF::writeHTML($html, true, false, true, false, '');
        PDF::Output($this->filepath, "F");
        return response()->download($this->filepath, $request->first_name . " " . $request->last_name . "cv.pdf")->deleteFileAfterSend(true);
    }
    public function downloadCoverLetter(Request $request)
    {
        PDF::AddPage('P', 'A4');
        $this->filepath = storage_path('cvs/' . "cover.pdf");

        $view = \View::make('jobs.cover_letter', ['data' => $request->all()]);
        $html = $view->render();

        PDF::writeHTML($html, true, false, true, false, '');
        PDF::Output($this->filepath, "F");
        return response()->download($this->filepath, "cover.pdf")->deleteFileAfterSend(true);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();
        $data['user_id'] = Auth::user()->id;
        Application::create($data);
        return response(["message" => "Your application has been submitted successfully"], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $record = Application::find($id);
        if ($record) {
            $data = $request->all();
            if ($request->email) {
                $subject = $request->subject;
                $message = $request->message;
            } else {
                $subject = "Application Status";
                if ($request->status == "Shortlisted") {
                    $message = "You have been " . $request->status . " for " . $record->job_title->job_title . " position";
                    ApplicationInterview::create(['application_id' => $record->id, 'interview_date' => $request->interview_date, 'invitation' => $message, 'comments' => $request->notes]);
                } elseif ($request->status == "Invited") {
                    $message = "You have been invited for " . $request->interview_level . " interview on " . date("d/m/Y h:i:sA", strtotime($request->interview_date));
                } elseif ($request->status == "Hired") {
                    $check = Personnel::find($record->user_id);
                    if ($check->status == 'Hired') {
                        return response(["message" => "Sorry, this candidate is already working with one of our clients"], 400);
                    } else {
                        $check->update(['status' => 'Hired', 'work_station_id' => $record->job_title->company_id, 'job_title_id' => $record->job_title->id, 'employment_type_id' => EmploymentType::where(['employment_type' => $record->job_title->job_type])->first()->id]);
                    }
                    $message = "Congratulations! You have been " . $request->status . " for " . $record->job_title->job_title . " position you had applied with us. More details will be shared with you later.";
                } elseif ($request->status == "Rejected") {
                    $message = "We appreciate you applying to the " . $record->job_title->job_title . ". Although you have some great skills and experience, we have decided to move forward with a different candidate whose experience more closely matches our needs.";
                } else {
                    $message = "Your job application status for " . $record->job_title->job_title . " has changed to " . $request->status;
                }
            }
            ApplicationHistory::create(['created_by' => Auth::user()->id, 'application_id' => $record->id, 'history' => $message, 'notes' => $request->notes, 'status' => $request->status]);
            $record->update($data);
            (new Notify())->sendEmail($record->personnel->email, $subject, ['name' => $record->personnel->first_name . " " . $record->personnel->last_name, 'message' => $message], 'jobs.notify', null);
            return response(["message" => "Application status have been updated to " . $request->status], 200);
        } else {
            return response(["message" => "Record not found"], 404);
        }
    }
    public function batchApplicationAction(Request $request)
    {
        foreach ((array) $request->application_ids as $id) {
            $record = Application::find($id['id']);
            $data = $request->all();
            if ($record) {
                if ($request->email) {
                    $subject = $request->subject;
                    $message = $request->message;
                } else {
                    $subject = "Application Status";
                    if ($request->status == "Shortlisted") {
                        $message = "You have been " . $request->status . " for " . $record->job_title->job_title . " position";
                        ApplicationInterview::create(['application_id' => $record->id, 'interview_date' => $request->interview_date, 'invitation' => $message, 'comments' => $request->notes]);
                    } elseif ($request->status == "Invited") {
                        $message = "You have been invited for " . $request->interview_level . " interview on " . date("d/m/Y h:i:sA", strtotime($request->interview_date));
                    } elseif ($request->status == "Hired") {
                        $message = "Congratulations! You have been " . $request->status . " for " . $record->job_title->job_title . " position you had applied with us. More details will be shared with you later.";
                    } elseif ($request->status == "Rejected") {
                        $message = "We appreciate you applying to the " . $record->job_title->job_title . ". Although you have some great skills and experience, we have decided to move forward with a different candidate whose experience more closely matches our needs.";
                    } else {
                        $message = "Your job application status for " . $record->job_title->job_title . " has changed to " . $request->status;
                    }
                }
                ApplicationHistory::create(['created_by' => Auth::user()->id, 'application_id' => $record->id, 'history' => $message, 'notes' => $request->notes, 'status' => $request->status]);
                $record->update($data);
                (new Notify())->sendEmail($record->personnel->email, $subject, ['name' => $record->personnel->first_name . " " . $record->personnel->last_name, 'message' => $message], 'jobs.notify', null);
            }
        }
        return response(["message" => "Batch applications status have been updated"], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
