<?php

namespace App\Http\Controllers\V1\Notifications;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\Notifications\NotificationResource;
use App\Models\V1\Notifications\Notification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class NotificationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return NotificationResource::collection(Notification::where(['recipient_id' => Auth::user()->id])->orderBy('id', 'DESC')->limit(5)->get());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();
        $data['user_id'] = Auth::user()->id;
        Notification::create($data);
        return response(["message" => "Notified"], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $record = Notification::find($id);
        if ($record) {
            $record->update($request->all());
            return response(["message" => "Notification has been updated"], 200);
        } else {
            return response(["message" => "Record not found"], 404);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy()
    {
        $record = Notification::where(['recipient_id' => Auth::user()->id]);
        if ($record) {
            $record->delete();
            return response(["message" => "You have cleared all notifications"], 200);
        } else {
            return response(["message" => "Record not found"], 404);
        }
    }
}
