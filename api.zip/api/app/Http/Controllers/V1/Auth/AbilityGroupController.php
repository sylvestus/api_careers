<?php

namespace App\Http\Controllers\V1\Auth;

use App\Http\Controllers\Controller;
use App\Models\V1\Auth\AbilityGroup;
use Illuminate\Http\Request;

class AbilityGroupController extends Controller
{
    public function index()
    {
        return response()->json(["data" => AbilityGroup::all()], 200);
    }

    public function store(Request $request)
    {
        if (AbilityGroup::create($request->all())) {
            return response(["message" => "Record has been created successfully"], 200);
        } else {
            return response(["message" => "Record creation failed"], 201);
        }
    }

    public function show($id)
    {
        $resource = AbilityGroup::findOrFail($id);
        return response()->json([new AbilityGroup($resource), 200]);
    }

    public function update(Request $request, $id)
    {
        $resource = AbilityGroup::findOrFail($id);

        if ($resource) {
            $resource->update($request->all());
            return response(["message" => "Record has been updated"], 200);
        } else {
            return response(["message" => "Record not found"], 404);
        }
    }

    public function destroy($id)
    {
        $resource = AbilityGroup::findOrFail($id);

        if ($resource) {
            $resource->delete();
            return response(["message" => "Record has been deleted"], 200);
        } else {
            return response(["message" => "Record not found"], 404);
        }
    }
}
