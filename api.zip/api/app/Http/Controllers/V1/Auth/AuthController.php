<?php

namespace App\Http\Controllers\V1\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\V1\Auth\ChangePasswordRequest;
use App\Http\Requests\V1\Auth\forgotPasswordRequest;
use App\Http\Requests\V1\Auth\SigninRequest;
use App\Http\Requests\V1\Auth\SignupRequest;
use App\Http\Resources\V1\Auth\AuditLogResource;
use App\Http\Resources\V1\Auth\UserResource;
use App\Models\V1\Auth\AuditLog;
use App\Models\V1\Auth\User;
use App\Models\V1\Company\Company;
use App\Models\V1\Company\Personnel;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Laravel\Socialite\Facades\Socialite;
use Illuminate\Support\Facades\Validator;

class AuthController extends Controller
{
    /**
     * Signin
     * @group Account Management
     * 
     * @return \Illuminate\Http\Response
     */
    
    public function signin(SigninRequest $request)
    {
        $fieldType = filter_var($request->email, FILTER_VALIDATE_EMAIL) ? 'email' : 'email';
        $fieldType = filter_var($request->email, FILTER_SANITIZE_NUMBER_INT) ? 'phone' : $fieldType;

        if (!auth()->attempt(['email' => $request->email, 'password' => $request->password])) {
            return response(['message' => 'Invalid account credentials'], 403);
        } else {
            auth()->attempt([$fieldType => $request->email, 'password' => $request->password]);
            return new UserResource(auth()->user());
        }
    }
    /**
     * Signup
     * @group Account Management
     *
     * @return \Illuminate\Http\Response
     */
    public function signup(SignupRequest $request)
    {
        $data = $request->all();
        $data['password'] = bcrypt($request->password);
        $data['role_id'] = 2;
        $data['name'] = $request->first_name . " " . $request->last_name;

        $usr = User::create($data);
        $employee = $request->all();
        $employee['id'] = $usr->id;
        Personnel::create($employee);

        $this->sendRegistrationEmail(['name' => $data['name'], 'email' => $request->email, 'company_name' => "Techsavanna", 'password' => $request->password, 'reset_url' => 'https://careers.techsavanna.technology/']);
        return response(['message' => 'Welcome to Techsavanna'], 200);
    }
    public function logoUrl($id)
    {
        $resource = Company::findOrFail($id);
        $extension = explode('/', mime_content_type($resource->company_logo))[1];
        $fileContent = explode(',', $resource->company_logo)[1];
        $filename = $resource->company_name . '.' . $extension;
        $filename = preg_replace('/\s+/', '_', $filename);
        $data = base64_decode($fileContent);
        Storage::put($filename, $data);
        $fileUrl = getenv('BASE_URL') . Storage::url('app/' . $filename);
        $filePath = storage_path('app/' . $filename);
        return response()->download($filePath, $filename)->deleteFileAfterSend(true);
    }
    public function loginCredentials($id)
    {
        $password = Str::random(8);
        $user = User::findOrFail($id);
        $user->update(['password' => Hash::make($password), 'verification_code'=>rand(100000, 999999), 'login_attempts' => 10]);

        $this->sendRegistrationEmail(['name' => $user->name, 'email' => $user->email, 'company_name' => "", 'password' => $password, 'reset_url' => 'https://https://careers.techsavanna.technology/login']);
        return response(['message' => 'Login credentials have been mailed to ' . $user->email], 200);
    }
    public function sendPassword($email)
    {
        $password = Str::random(8);
        $user = User::where(['email'=>$email])->first();
        if($user){
        $user->update(['password' => Hash::make($password), 'verification_code'=>rand(100000, 999999), 'login_attempts' => 10]);

        $this->sendRegistrationEmail(['name' => $user->name, 'email' => $user->email, 'company_name' => "", 'password' => $password, 'reset_url' => 'https://https://careers.techsavanna.technology/login']);
        return response(['message' => 'Login credentials have been mailed to ' . $user->email], 200);
        }else{
            return response(['message' => 'No user account associated with ' . $user->email], 200);
        }
    }
    public function profilePhotoUrl($id)
    {
        $resource = User::findOrFail($id);
        $extension = explode('/', mime_content_type($resource->profile_photo))[1];
        $fileContent = explode(',', $resource->profile_photo)[1];
        $filename = rand(10, 100000) . '.' . $extension;
        $filename = preg_replace('/\s+/', '_', $filename);
        $data = base64_decode($fileContent);
        Storage::put($filename, $data);
        $fileUrl = getenv('BASE_URL') . Storage::url('app/' . $filename);
        $filePath = storage_path('app/' . $filename);
        return response()->download($filePath, $filename)->deleteFileAfterSend(true);
    }

    /**
     * Change Password
     * @group Account Management
     * 
     * @return \Illuminate\Http\Response
     */
    public function changePassword(ChangePasswordRequest $request)
    {
        if (!auth()->attempt(['email' => $request->email, 'password' => $request->current_password])) {
            return response(['message' => "Current password is not correct"], 401);
        } else {
            $user = User::find(auth()->user()->id);
            $user->update(['login_attempts' => 0, 'password' => bcrypt($request->new_password)]);
            $user->save();
            AuditLog::create([
                'company_id' => $user->company_id,
                'user_id' => $user->id,
                'ip' => $request->getClientIp(),
                'url' => $request->getUri(),
                'user_agent' => $request->server('HTTP_USER_AGENT'),
                'method' => $request->getMethod(),
                'request' => "Attempt to change password",
                'response' => "Password changed successfully"
            ]);
            return response(['message' => "Password changed successfully"]);
        }
    }
    public function  forgotPassword(forgotPasswordRequest $request)
    {
        $user = User::with('company')->where('email', $request->email)->first();
        if ($user) {
            $token = Str::random(64);
            $user->update(['reset_token' => $token]);
            $reset_url =  $request->callback . '/' . $token;
            $email['email'] = $request->email;
            $email['name'] = $user->name;
            $email['reset_url'] = $reset_url;
            $email['subject'] = 'Password Reset';
            $this->sendResetEmail($email);
            AuditLog::create([
                'company_id' => $user->company_id,
                'user_id' => $user->id,
                'ip' => $request->getClientIp(),
                'url' => $request->getUri(),
                'user_agent' => $request->server('HTTP_USER_AGENT'),
                'method' => $request->getMethod(),
                'request' => "Request password reset",
                'response' => "Reset password link sent on your email address"
            ]);
            return response(['message' => "Reset password link sent on your email address"], 200);
        } else {
            return response(['message' => "User does not exist"], 403);
        }
    }
    public function  resetPassword(Request $request)
    {
        $request->validate([
            'password' => 'required',
            'password_confirm' => 'required|same:password',
            'token' => 'required|string',
        ]);
        $user = User::where('reset_token', $request->token)->first();
        if ($user) {
            $user->password = Hash::make($request->password);
            $user->reset_token = null;
            $user->save();
            AuditLog::create([
                'company_id' => $user->company_id,
                'user_id' => $user->id,
                'ip' => $request->getClientIp(),
                'url' => $request->getUri(),
                'user_agent' => $request->server('HTTP_USER_AGENT'),
                'method' => $request->getMethod(),
                'request' => "Attempt to reset password",
                'response' => "Password reset successfully"
            ]);
            return response(['message' => "User password has been reset successfully"], 200);
        } else {
            return response(['message' => "Invalid link"], 403);
        }
    }
    public function accessLogs(Request $request)
    {
        $size = $request->size ? $request->size : 10;
        if ($request->search) {
            return AuditLogResource::collection(AuditLog::where(['company_id' => $request->company_id])->where('request', 'like', '%' . $request->search . '%')->where('response', 'like', '%' . $request->search . '%')->orderBy('id', 'DESC')->paginate($size));
        } else {
            return AuditLogResource::collection(AuditLog::where(['company_id' => $request->company_id])->orderBy('id', 'DESC')->paginate($size));
        }
    }
    public function index()
    {
        return response()->json([
            "data" => User::get()
        ], 200);
    }
    public function show($id)
    {
        return response()->json(User::find($id), 200);
    }
    public function update(Request $request, $id): object
    {
        if (User::where('id', $id)->exists()) {
            $user = User::find($id);

            $user->name = is_null($request->name) ? $user->name : "$request->name";
            $user->email = is_null($request->email) ? $user->email : $request->email;
            $user->phone = is_null($request->phone) ? $user->phone : $request->phone;
            $user->profile_photo = is_null($request->profile_photo) ? $user->profile_photo : $request->profile_photo;
            $user->save();

            return response()->json([
                "message" => "records updated successfully"
            ], 200);
        } else {
            return response()->json([
                "message" => "user not found"
            ], 404);
        }
    }
    public function sendResetEmail($request)
    {
        $data = [
            'user_name' => $request['name'],
            'user_email' => $request['email'],
            'reset_url' => $request['reset_url'],
        ];
        $this->sendTo = $request['email'];
        $result = Mail::send(['html' => view('emails.reset_password', ['data' => $data])], $data, function ($message) {
            $message->subject('Password Reset Link');
            $message->to($this->sendTo);
        });
        return $result;
    }
    public function sendVerificationCode($request)
    {
        $data = [
            'user_name' => $request['name'],
            'verification_code' => $request['verification_code'],
        ];

        $this->sendTo = $request['email'];
        $result = Mail::send(['html' => view('emails.verification_code', ['data' => $data])], $data, function ($message) {
            $message->subject('verification code');
            $message->to($this->sendTo);
        });
        return $result;
    }
    public function sendRegistrationEmail($user)
    {
        $data = [
            'user_name' => $user['name'],
            'user_email' => $user['email'],
            'company_name' => $user['company_name'],
            'password' => $user['password'],
            'reset_url' => $user['reset_url'],
        ];
        $this->sendTo = $user['email'];

        $result = Mail::send(['html' => view('emails.welcome', ['data' => $data])], $data, function ($message) {
            $message->subject('Welcome On Board');
            $message->to($this->sendTo);
        });
        return $result;
    }

    public function handleProviderCallback(Request $request)
    {
        $validator = Validator::make($request->only('provider', 'access_provider_token'), [
            'provider' => ['required', 'string'],
            'access_provider_token' => ['required', 'string']
        ]);
        if ($validator->fails())
            return response()->json($validator->errors(), 400);
        $provider = $request->provider;
        $validated = $this->validateProvider($provider);
        if (!is_null($validated))
            return $validated;
        $providerUser = Socialite::driver($provider)->userFromToken($request->access_provider_token);
        $user = User::firstOrCreate(
            [
                'email' => $providerUser->getEmail()
            ],
            [
                'name' => $providerUser->getName(),
            ]
        );
        $user['access_token'] = $user->createToken('Sanctom+Socialite')->plainTextToken;
        // $data =  [
        //     'token' => $user->createToken('Sanctom+Socialite')->plainTextToken,
        //     'user' => $user,
        // ];
        // return response()->json($data, 200);
// return $user;
        return new UserResource($user);
    }

    protected function validateProvider($provider)
    {
        if (!in_array($provider, ['google'])) {
            return response()->json(["message" => 'You can only login via google account'], 400);
        }
    }
}
