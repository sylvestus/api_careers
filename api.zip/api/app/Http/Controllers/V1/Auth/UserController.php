<?php

namespace App\Http\Controllers\V1\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\V1\Company\PersonnelRequest;
use App\Http\Resources\V1\Auth\UsersResource;
use App\Models\V1\Auth\User;
use App\Models\V1\Company\Company;
use App\Models\V1\Company\Personnel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return response()->json(["data" => UsersResource::collection(User::get())], 200);
    }
    /**
     * Display a listing of the client's users
     * 
     * @group Client data
     * @authenticated
     *
     * @return \Illuminate\Http\Response
     */
    public function clientUsers(Request $request)
    {
        return response()->json(["data" => UsersResource::collection(User::where(['company_id'=>$request->company_id])->get())], 200);
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(PersonnelRequest $request)
    {
        $data = $request->all();
        $password = substr(str_shuffle('1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcefghijklmnopqrstuvwxyz'), 0, 7);
        
        $data['password'] = bcrypt($password);
        $data['name'] = $request->first_name." ".$request->last_name;
        $usr = User::create($data);

        $employee = new Personnel();
        $employee->id = $usr->id;
        $employee->company_id = $request->company_id;
        $employee->first_name = $request->first_name;
        $employee->last_name = $request->last_name;
        $employee->email = $request->email;
        $employee->phone = $request->phone;
        $employee->save();
        
        if ($usr) {
            $data = [
                'user_name' => $data['name'],
                'user_email' => $data['email'],
                'company_name' => Company::find($request->company_id)->company_name,
                'password' => $password,
                'reset_url' => 'https://https://careers.techsavanna.technology/login',
            ];
            $this->sendTo = $data['user_email'];
            Mail::send(['html' => view('emails.welcome', ['data' => $data])], $data, function ($message) {
                $message->subject('Welcome On Board');
                $message->to($this->sendTo);
            });
            return response(["message" => "Record has been created successfully"], 200);
        } else {
            return response(["message" => "Record creation failed"], 201);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $record = User::find($id);
        if ($record) {
            $record->update($request->all());
            return response(["message" => "Record has been updated"], 200);
        } else {
            return response(["message" => "Record not found"], 404);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        User::find($id)->delete();
        return response(["message" => "Record has been deleted"], 200);
    }
}
