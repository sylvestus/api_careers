<?php

namespace App\Http\Controllers\V1\Auth;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\Auth\AbilityResource;
use App\Models\V1\Auth\Abilities;
use Illuminate\Http\Request;

class AbilitiesController extends Controller
{
    public function index()
    {
        $resource = Abilities::all();
        return response()->json(["data" => AbilityResource::collection($resource)], 200);
    }

    public function store(Request $request)
    {
        if (Abilities::create($request->all())) {
            return response(["message" => "Record has been created successfully"], 200);
        } else {
            return response(["message" => "Record creation failed"], 201);
        }
    }

    public function show($id)
    {
        $resource = Abilities::findOrFail($id);
        return response()->json([new AbilityResource($resource), 200]);
    }

    public function update(Request $request, $id)
    {
        $resource = Abilities::findOrFail($id);

        if ($resource) {
            $resource->update($request->all());
            return response(["message" => "Record has been updated"], 200);
        } else {
            return response(["message" => "Record not found"], 404);
        }
    }

    public function destroy($id)
    {
        $resource = Abilities::findOrFail($id);

        if ($resource) {
            $resource->delete();
            return response(["message" => "Record has been deleted"], 200);
        } else {
            return response(["message" => "Record not found"], 404);
        }
    }
}
