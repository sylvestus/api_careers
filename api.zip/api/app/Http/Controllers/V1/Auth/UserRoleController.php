<?php

namespace App\Http\Controllers\V1\Auth;

use App\Http\Controllers\Controller;
use App\Http\Resources\V1\Auth\AbilityGroupResource;
use App\Http\Resources\V1\Auth\RoleResource;
use App\Models\V1\Auth\Abilities;
use App\Models\V1\Auth\AbilityGroup;
use App\Models\V1\Auth\Role;
use Illuminate\Http\Request;

class UserRoleController extends Controller
{
    // use ApiResponse;

    // function __construct()
    // {
    //     $this->middleware(['auth:api'], ['except' => []]);
    // }

    public function index()
    {
        $resource = Role::get();
        return response()->json(["data" => ['abilities' => AbilityGroupResource::collection(AbilityGroup::with('abilities')->get()), 'roles' => RoleResource::collection($resource)]], 200);
    }
    /**
     * Display a listing of the client's users-role
     * 
     * @group Client data
     * @authenticated
     *
     * @return \Illuminate\Http\Response
     */
    public function clientRoles(Request $request)
    {
        $resource = Role::where(['company_id' => $request->company_id])->orWhereNull('company_id')->get();
        return response()->json(["data" => ['abilities' => AbilityGroupResource::collection(AbilityGroup::with('abilities')->get()), 'roles' => RoleResource::collection($resource)]], 200);
    }

    public function store(Request $request)
    {
        $selected_abilities_id = [];
        foreach ($request->ability_ids as $item) {
            $ability = Abilities::where('title', $item)->first();
            if (isset($ability['id'])) {
                array_push($selected_abilities_id, $ability['id']);
            }
        }
        $resource = Role::create($request->all());
        $resource->abilities()->sync($selected_abilities_id);
        return response()->json([new RoleResource($resource), 200]);
    }

    public function show($id)
    {
        $resource = Role::findOrFail($id);
        return response()->json([new RoleResource($resource), 200]);
    }

    public function update(Request $request, $id)
    {
        $selected_abilities_id = [];
        foreach ($request->ability_ids as $item) {
            $ability = Abilities::where('title', $item)->first();
            if (isset($ability['id'])) {
                array_push($selected_abilities_id, $ability['id']);
            }
        }
        $resource = Role::findOrFail($id);
        $resource->update($request->all());
        $resource->abilities()->sync($selected_abilities_id);
        return response()->json(['message' => 'Role Permissions updated successfully', 200]);
    }

    public function destroy($id)
    {
        $resource = Role::findOrFail($id);
        $resource->delete();
        return response()->json([new RoleResource($resource), 200]);
    }
}
