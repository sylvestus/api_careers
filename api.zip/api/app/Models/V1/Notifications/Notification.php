<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\V1\Notifications;

use App\Models\V1\Auth\User;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

/**
 * Class Notification
 * 
 * @property int $id
 * @property int $user_id
 * @property int $recipient_id
 * @property string $notification
 * @property string $action
 * @property int|null $status
 * @property Carbon $created_at
 * @property Carbon|null $updated_at
 * 
 * @property User $user
 *
 * @package App\Models
 */
class Notification extends Model
{
	protected $table = 'notifications';

	protected $casts = [
		'user_id' => 'int',
		'recipient_id' => 'int',
		'status' => 'int'
	];

	protected $fillable = [
		'user_id',
		'recipient_id',
		'notification',
		'action',
		'status'
	];

	public function user()
	{
		return $this->belongsTo(User::class, 'recipient_id');
	}
}
