<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\V1\Job;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;
use App\Models\V1\Company\Personnel;
use App\Models\V1\Company\JobTitle;

/**
 * Class Application
 * 
 * @property int $id
 * @property int $user_id
 * @property int $job_id
 * @property string $cover_letter
 * @property string $status
 * @property Carbon $created_at
 * @property Carbon|null $updated_at
 * 
 * @property JobTitle $job_title
 * @property Personnel $personnel
 * @property Collection|ApplicationHistory[] $application_histories
 * @property Collection|ApplicationInterview[] $application_interviews
 *
 * @package App\Models
 */
class Application extends Model
{
	protected $table = 'applications';

	protected $casts = [
		'user_id' => 'int',
		'job_id' => 'int'
	];

	protected $fillable = [
		'user_id',
		'job_id',
		'cover_letter',
		'status'
	];

	public function job_title()
	{
		return $this->belongsTo(JobTitle::class, 'job_id');
	}

	public function personnel()
	{
		return $this->belongsTo(Personnel::class, 'user_id');
	}

	public function application_histories()
	{
		return $this->hasMany(ApplicationHistory::class);
	}

	public function application_interviews()
	{
		return $this->hasMany(ApplicationInterview::class);
	}
}
