<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\V1\Job;

use App\Models\V1\Auth\User;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

/**
 * Class ApplicationHistory
 * 
 * @property int $id
 * @property int $application_id
 * @property string $history
 * @property string|null $notes
 * @property string|null $status
 * @property int|null $created_by
 * @property Carbon $created_at
 * 
 * @property Application $application
 * @property User|null $user
 *
 * @package App\Models
 */
class ApplicationHistory extends Model
{
	protected $table = 'application_history';
	public $timestamps = false;

	protected $casts = [
		'application_id' => 'int',
		'created_by' => 'int'
	];

	protected $fillable = [
		'application_id',
		'history',
		'notes',
		'status',
		'created_by'
	];

	public function application()
	{
		return $this->belongsTo(Application::class);
	}

	public function user()
	{
		return $this->belongsTo(User::class, 'created_by');
	}
}
