<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\V1\Job;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

/**
 * Class ApplicationInterview
 * 
 * @property int $id
 * @property int $application_id
 * @property Carbon|null $interview_date
 * @property string|null $invitation
 * @property string|null $comments
 * @property Carbon $updated_at
 * @property Carbon $created_at
 * 
 * @property Application $application
 *
 * @package App\Models
 */
class ApplicationInterview extends Model
{
	protected $table = 'application_interviews';

	protected $casts = [
		'application_id' => 'int'
	];

	protected $dates = [
		'interview_date'
	];

	protected $fillable = [
		'application_id',
		'interview_date',
		'invitation',
		'comments'
	];

	public function application()
	{
		return $this->belongsTo(Application::class);
	}
}
