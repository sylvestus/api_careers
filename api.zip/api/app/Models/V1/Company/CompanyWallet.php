<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\V1\Company;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

/**
 * Class CompanyWallet
 * 
 * @property int $id
 * @property int $company_id
 * @property int|null $personnel_id
 * @property string $type
 * @property float $amount
 * @property float $fee
 * @property float $balance
 * @property float $company_balance
 * @property string|null $description
 * @property int $status
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * 
 * @property Company $company
 * @property Personnel|null $personnel
 *
 * @package App\Models
 */
class CompanyWallet extends Model
{
	protected $table = 'company_wallets';
	public $timestamps = false;

	protected $casts = [
		'company_id' => 'int',
		'personnel_id' => 'int',
		'amount' => 'float',
		'fee' => 'float',
		'balance' => 'float',
		'status' => 'int'
	];

	protected $fillable = [
		'reference',
		'company_id',
		'personnel_id',
		'payment_method',
		'type',
		'category',
		'module',
		'amount',
		'fee',
		'balance',
		'company_balance',
		'description',
		'status'
	];

	public function company()
	{
		return $this->belongsTo(Company::class);
	}

	public function personnel()
	{
		return $this->belongsTo(Personnel::class);
	}
}
