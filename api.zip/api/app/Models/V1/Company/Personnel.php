<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\V1\Company;

use App\Models\V1\Definitions\Bank;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class Personnel
 * 
 * @property int $id
 * @property int|null $company_id
 * @property string $first_name
 * @property string|null $middle_name
 * @property string $last_name
 * @property string|null $phone
 * @property string|null $email
 * @property string|null $id_number
 * @property string|null $country
 * @property Carbon|null $date_of_birth
 * @property string|null $kra_pin
 * @property string|null $nhif_number
 * @property string|null $nssf_number
 * @property string|null $gender
 * @property string|null $marital_status
 * @property int|null $department_id
 * @property int|null $job_title_id
 * @property string|null $employee_number
 * @property int|null $employment_type_id
 * @property int|null $work_station_id
 * @property Carbon|null $employment_start_date
 * @property float|null $basic_salary
 * @property string|null $payment_method
 * @property string|null $account_number
 * @property string|null $bank
 * @property string|null $bank_code
 * @property string|null $bank_branch
 * @property string|null $status
 * @property string|null $city
 * @property string|null $highest_qualification
 * @property string|null $industry
 * @property string|null $experience
 * @property string|null $availability
 * @property Carbon|null $updated_at
 * @property Carbon $created_at
 * @property string|null $deleted_at
 * 
 * @property Company|null $company
 * @property Department|null $department
 * @property EmploymentType|null $employment_type
 * @property JobTitle|null $job_title
 * @property Collection|Department[] $departments
 *
 * @package App\Models
 */
class Personnel extends Model
{
	use SoftDeletes;
	protected $table = 'personnel';
	public $incrementing = false;

	protected $casts = [
		'id' => 'int',
		'company_id' => 'int',
		'department_id' => 'int',
		'job_title_id' => 'int',
		'employment_type_id' => 'int',
		'work_station_id' => 'int',
		'basic_salary' => 'float'
	];

	protected $dates = [
		'date_of_birth',
		'employment_start_date'
	];

	protected $fillable = [
		'id',
		'company_id',
		'first_name',
		'middle_name',
		'last_name',
		'phone',
		'email',
		'id_number',
		'country',
		'date_of_birth',
		'kra_pin',
		'nhif_number',
		'nssf_number',
		'gender',
		'marital_status',
		'department_id',
		'job_title_id',
		'employee_number',
		'employment_type_id',
		'work_station_id',
		'employment_start_date',
		'basic_salary',
		'payment_method',
		'account_number',
		'bank',
		'bank_code',
		'bank_branch',
		'status',
		'city',
		'highest_qualification',
		'industry',
		'experience',
		'availability'
	];

	public function company()
	{
		return $this->belongsTo(Company::class);
	}

	public function work_station()
	{
		return $this->belongsTo(Company::class, 'work_station_id');
	}

	public function department()
	{
		return $this->belongsTo(Department::class);
	}

	public function employment_type()
	{
		return $this->belongsTo(EmploymentType::class);
	}

	public function job_title()
	{
		return $this->belongsTo(JobTitle::class);
	}

	public function bank()
	{
		return $this->belongsTo(Bank::class);
	}

	public function departments()
	{
		return $this->hasMany(Department::class, 'hod');
	}
}
