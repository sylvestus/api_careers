<?php

namespace App\Models\V1\Company;

use App\Models\V1\Auth\User;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithBatchInserts;
use Maatwebsite\Excel\Concerns\WithUpserts;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;

class UsersImport implements ToModel, WithBatchInserts, WithHeadingRow, WithUpserts
{
    public $company_id;

    function __construct($company_id)
    {
        $this->company_id = $company_id;
    }

    /**
     * @param array $row
     *
     * @return User|null
     */
    public function model(array $row)
    {
        $pass =  Str::random(8);
        $data = [];
        $data['company_id'] = $this->company_id;
        $data['role_id'] = 2;
        $data['name'] = $row['first_name'] . " " . $row['last_name'];
        $data['phone'] = formatPhone($row['phone']);
        $data['email'] = $row['email'];
        $data['username'] = $row['email'];
        $data['password'] = bcrypt($pass);
        $data['login_attempts'] = 10;

        $user = User::create($data);
        $department = Department::where(['department' => $row['department'], 'company_id' => $this->company_id])->first();
        $job_title = JobTitle::where(['job_title' => $row['job_title'], 'company_id' => $this->company_id])->first();
        $employment_type = EmploymentType::where(['employment_type' => $row['employment_type'], 'company_id' => $this->company_id])->first();
        if ($department) {
            $department_id = $department->id;
        } else {
            $department_id = Department::create(['company_id' => $this->company_id, 'department' => $row['department']])->id;
        }
        if ($job_title) {
            $job_title_id = $job_title->id;
        } else {
            $job_title_id = JobTitle::create(['company_id' => $this->company_id, 'job_title' => $row['job_title'], 'department_id' => $department_id])->id;
        }
        if ($employment_type) {
            $employment_type_id = $employment_type->id;
        } else {
            $employment_type_id = EmploymentType::create(['company_id' => $this->company_id, 'employment_type' => $row['employment_type']])->id;
        }
        $this->sendRegistrationEmail(['name' => $data['name'], 'email' => $data['email'], 'company_name' => "", 'password' => $pass, 'reset_url' => 'https://https://careers.techsavanna.technology/login']);

        return new Personnel([
            'id' => $user->id,
            'company_id' => $this->company_id,
            'first_name' => $row['first_name'],
            'middle_name' => $row['middle_name'],
            'last_name' => $row['last_name'],
            'phone' => formatPhone($row['phone']),
            'email' => $row['email'],
            'country' => 'Kenya',
            'id_number' => $row['id_number'],
            'date_of_birth' => date("Y-m-d", strtotime($row['date_of_birth'])),
            'kra_pin' => $row['kra_pin'],
            'department_id' => $department_id,
            'job_title_id' => $job_title_id,
            'employee_number' => $row['employee_number'],
            'employment_type_id' => $employment_type_id,
            'employment_start_date' => date("Y-m-d"),
        ]);
    }
    public function batchSize(): int
    {
        return 1000;
    }
    public function uniqueBy()
    {
        return 'email';
    }
    public function sendRegistrationEmail($user)
    {
        $data = [
            'user_name' => $user['name'],
            'user_email' => $user['email'],
            'company_name' => $user['company_name'],
            'password' => $user['password'],
            'reset_url' => $user['reset_url'],
        ];
        $this->sendTo = $user['email'];

        $result = Mail::send(['html' => view('emails.welcome', ['data' => $data])], $data, function ($message) {
            $message->subject('Welcome On Board');
            $message->to($this->sendTo);
        });
        return $result;
    }
}
