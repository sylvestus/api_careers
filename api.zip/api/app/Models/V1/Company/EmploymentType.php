<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\V1\Company;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;

/**
 * Class EmploymentType
 * 
 * @property int $id
 * @property int $company_id
 * @property string $employment_type
 * @property bool|null $deduct_tax
 * @property bool|null $tax_type
 * @property bool|null $deduct_nhif
 * @property bool|null $deduct_nssf
 * @property bool|null $pensionable
 * @property Carbon $created_at
 * @property Carbon $updated_at
 * 
 * @property Company $company
 * @property Collection|Personnel[] $personnels
 *
 * @package App\Models
 */
class EmploymentType extends Model
{
	protected $table = 'employment_types';

	protected $casts = [
		'company_id' => 'int',
		'deduct_tax' => 'bool',
		'deduct_nhif' => 'bool',
		'deduct_nssf' => 'bool',
		'pensionable' => 'bool'
	];

	protected $fillable = [
		'company_id',
		'employment_type',
		'deduct_tax',
		'tax_type',
		'deduct_nhif',
		'deduct_nssf',
		'pensionable'
	];

	public function company()
	{
		return $this->belongsTo(Company::class);
	}

	public function personnels()
	{
		return $this->hasMany(Personnel::class);
	}
}
