<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\V1\Company;

use App\Models\V1\Job\Application;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;

/**
 * Class JobTitle
 * 
 * @property int $id
 * @property int $company_id
 * @property int|null $department_id
 * @property string|null $job_title
 * @property string|null $job_type
 * @property string|null $industry
 * @property string|null $country
 * @property string|null $experience
 * @property string|null $career_level
 * @property string|null $location
 * @property Carbon|null $application_deadline
 * @property string|null $description
 * @property string|null $skills
 * @property Carbon|null $created_at
 * @property Carbon $updated_at
 * 
 * @property Department|null $department
 * @property Company $company
 * @property Collection|Application[] $applications
 * @property Collection|Personnel[] $personnels
 *
 * @package App\Models
 */
class JobTitle extends Model
{
	protected $table = 'job_titles';

	protected $casts = [
		'company_id' => 'int',
		'department_id' => 'int'
	];

	protected $dates = [
		'application_deadline'
	];

	protected $fillable = [
		'company_id',
		'department_id',
		'job_title',
		'job_type',
		'industry',
		'country',
		'experience',
		'career_level',
		'location',
		'application_deadline',
		'description',
		'skills'
	];

	public function department()
	{
		return $this->belongsTo(Department::class);
	}

	public function company()
	{
		return $this->belongsTo(Company::class);
	}

	public function applications()
	{
		return $this->hasMany(Application::class, 'job_id');
	}

	public function personnels()
	{
		return $this->hasMany(Personnel::class);
	}
}
