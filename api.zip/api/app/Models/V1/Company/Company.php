<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\V1\Company;

use App\Models\V1\Auth\Role;
use App\Models\V1\Billing\Subscription;
use App\Models\V1\Budget\Budget;
use App\Models\V1\Budget\BudgetApproval;
use App\Models\V1\Budget\BudgetApprover;
use App\Models\V1\Budget\BudgetMember;
use App\Models\V1\Expense\Expense;
use App\Models\V1\Expense\ExpenseCategory;
use App\Models\V1\Payroll\PayElement;
use App\Models\V1\Payroll\Payroll;
use App\Models\V1\Payroll\PayrollMusterRoll;
use App\Models\V1\Payroll\PayrollPersonnel;
use App\Models\V1\Payroll\PersonnelPayElement;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class Company
 * 
 * @property int $id
 * @property int|null $parent_id
 * @property string $company_logo
 * @property string $company_name
 * @property string $merchant_code
 * @property string|null $business_regno
 * @property Carbon|null $incorporation_date
 * @property string|null $nhif_number
 * @property string|null $nssf_number
 * @property string|null $kra_pin
 * @property string $email
 * @property string $phone
 * @property string|null $company_size
 * @property string|null $industry
 * @property string|null $physical_address
 * @property string|null $country
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * @property string|null $deleted_at
 * 
 * @property Company|null $company
 * @property Collection|BudgetApproval[] $budget_approvals
 * @property Collection|BudgetApprover[] $budget_approvers
 * @property Collection|BudgetMember[] $budget_members
 * @property Collection|Budget[] $budgets
 * @property Collection|Company[] $companies
 * @property Collection|CompanyWallet[] $company_wallets
 * @property Collection|Department[] $departments
 * @property Collection|EmploymentType[] $employment_types
 * @property Collection|ExpenseCategory[] $expense_categories
 * @property Collection|Expense[] $expenses
 * @property Collection|JobTitle[] $job_titles
 * @property Collection|PayElement[] $pay_elements
 * @property Collection|PayrollMusterRoll[] $payroll_muster_rolls
 * @property Collection|PayrollPersonnel[] $payroll_personnels
 * @property Collection|Payroll[] $payrolls
 * @property Collection|Personnel[] $personnels
 * @property Collection|PersonnelPayElement[] $personnel_pay_elements
 * @property Collection|Role[] $roles
 * @property Collection|Subscription[] $subscriptions
 * @property Collection|User[] $users
 *
 * @package App\Models
 */
class Company extends Model
{
	use SoftDeletes;
	protected $table = 'companies';

	protected $casts = [
		'parent_id' => 'int'
	];

	protected $dates = [
		'incorporation_date'
	];

	protected $fillable = [
		'parent_id',
		'company_logo',
		'company_name',
		'merchant_code',
		'business_regno',
		'incorporation_date',
		'nhif_number',
		'nssf_number',
		'kra_pin',
		'email',
		'phone',
		'company_size',
		'industry',
		'physical_address',
		'country'
	];

	public function company()
	{
		return $this->belongsTo(Company::class, 'parent_id');
	}

	public function budget_approvals()
	{
		return $this->hasMany(BudgetApproval::class);
	}

	public function budget_approvers()
	{
		return $this->hasMany(BudgetApprover::class);
	}

	public function budget_members()
	{
		return $this->hasMany(BudgetMember::class);
	}

	public function budgets()
	{
		return $this->hasMany(Budget::class);
	}

	public function companies()
	{
		return $this->hasMany(Company::class, 'parent_id');
	}

	public function company_wallets()
	{
		return $this->hasMany(CompanyWallet::class);
	}

	public function departments()
	{
		return $this->hasMany(Department::class);
	}

	public function employment_types()
	{
		return $this->hasMany(EmploymentType::class);
	}

	public function expense_categories()
	{
		return $this->hasMany(ExpenseCategory::class);
	}

	public function expenses()
	{
		return $this->hasMany(Expense::class);
	}

	public function job_titles()
	{
		return $this->hasMany(JobTitle::class);
	}

	public function pay_elements()
	{
		return $this->hasMany(PayElement::class);
	}

	public function payroll_muster_rolls()
	{
		return $this->hasMany(PayrollMusterRoll::class);
	}

	public function payroll_personnels()
	{
		return $this->hasMany(PayrollPersonnel::class);
	}

	public function payrolls()
	{
		return $this->hasMany(Payroll::class);
	}

	public function personnels()
	{
		return $this->hasMany(Personnel::class, 'work_station_id');
	}

	public function personnel_pay_elements()
	{
		return $this->hasMany(PersonnelPayElement::class);
	}

	public function roles()
	{
		return $this->hasMany(Role::class);
	}

	public function subscriptions()
	{
		return $this->hasMany(Subscription::class);
	}

	public function users()
	{
		return $this->hasMany(User::class);
	}

	public function transactions()
	{
		return $this->hasMany(CompanyWallet::class);
	}

	public function validTransactions()
	{
		return $this->transactions()->where('status', 1);
	}

	public function credit()
	{
		return $this->validTransactions()
			->where(['type' => 'credit', 'status' => 1])
			->sum('amount');
	}

	public function debit()
	{
		return $this->validTransactions()
			->where(['type' => 'debit', 'status' => 1])
			->sum('amount');
	}

	public function balance()
	{
		return $this->credit() - $this->debit();
	}

	public function allowWithdraw($amount): bool
	{
		return $this->balance() >= $amount;
	}
}
