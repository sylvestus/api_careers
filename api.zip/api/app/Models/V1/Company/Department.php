<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\V1\Company;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;

/**
 * Class Department
 * 
 * @property int $id
 * @property int $company_id
 * @property string $department
 * @property int|null $hod
 * @property Carbon $created_at
 * @property Carbon|null $updated_at
 * 
 * @property Company $company
 * @property Personnel|null $personnel
 * @property Collection|JobTitle[] $job_titles
 * @property Collection|Personnel[] $personnels
 *
 * @package App\Models
 */
class Department extends Model
{
	protected $table = 'departments';

	protected $casts = [
		'company_id' => 'int',
		'hod' => 'int'
	];

	protected $fillable = [
		'company_id',
		'department',
		'hod'
	];

	public function company()
	{
		return $this->belongsTo(Company::class);
	}

	public function personnel()
	{
		return $this->belongsTo(Personnel::class, 'hod');
	}

	public function job_titles()
	{
		return $this->hasMany(JobTitle::class);
	}

	public function personnels()
	{
		return $this->hasMany(Personnel::class);
	}
}
