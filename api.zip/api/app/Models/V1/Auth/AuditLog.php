<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\V1\Auth;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class AuditLog
 * 
 * @property int $id
 * @property int|null $company_id
 * @property int|null $user_id
 * @property string $ip
 * @property string|null $user_agent
 * @property string $url
 * @property string $method
 * @property string|null $request
 * @property string|null $response
 * @property Carbon $created_at
 * @property Carbon|null $updated_at
 * @property string|null $deleted_at
 * 
 * @property User|null $user
 *
 * @package App\Models
 */
class AuditLog extends Model
{
	use SoftDeletes;
	protected $table = 'audit_logs';

	protected $casts = [
		'company_id' => 'int',
		'user_id' => 'int'
	];

	protected $fillable = [
		'company_id',
		'user_id',
		'ip',
		'user_agent',
		'url',
		'method',
		'request',
		'response'
	];

	public function user()
	{
		return $this->belongsTo(User::class);
	}
}
