<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\V1\Auth;

use Carbon\Carbon;
use App\Models\V1\Company\Company;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

/**
 * Class User
 * 
 * @property int $id
 * @property int $company_id
 * @property int $role_id
 * @property string $name
 * @property string $email
 * @property string $phone
 * @property string|null $profile_photo
 * @property int|null $login_attempts
 * @property string|null $auth_code
 * @property Carbon|null $email_verified_at
 * @property string $password
 * @property string|null $remember_token
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * 
 * @property Company $company
 * @property Role $role
 *
 * @package App\Models
 */
class User extends Authenticatable implements MustVerifyEmail
{
    use HasApiTokens, HasFactory, Notifiable, SoftDeletes;
	
	public $timestamps = false;
    
	protected $table = 'users';

	protected $casts = [
		'company_id' => 'int',
		'role_id' => 'int',
		'login_attempts' => 'int'
	];

	protected $dates = [
		'email_verified_at'
	];

	protected $hidden = [
		'password',
		'remember_token'
	];

	protected $fillable = [
		'company_id',
		'role_id',
		'name',
		'email',
		'phone',
		'profile_photo',
		'cover_letter',
		'login_attempts',
		'auth_code',
		'email_verified_at',
		'password',
		'reset_token',
		'remember_token'
	];

	public function role()
	{
		return $this->belongsTo(Role::class);
	}

	public function company()
	{
		return $this->belongsTo(Company::class);
	}

	public function payroll_personnels()
	{
		return $this->hasMany(PayrollPersonnel::class, 'created_by');
	}
}
