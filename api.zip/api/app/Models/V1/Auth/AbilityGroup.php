<?php

namespace App\Models\V1\Auth;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AbilityGroup extends Model
{
    use HasFactory;

    protected $table = 'ability_groups';

    protected $fillable = [
        'title',
        'description',
    ];
    public function abilities(){
        return $this->hasMany(Abilities::class, 'group_id', 'id');
    }
}
