<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\V1\Auth;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;

/**
 * Class Role
 * 
 * @property int $id
 * @property int $company_id
 * @property string $title
 * @property string|null $description
 * @property Carbon $created_at
 * @property Carbon|null $updated_at
 * @property string|null $deleted_at
 * 
 * @property Collection|User[] $users
 *
 * @package App\Models
 */
class Role extends Model
{
	protected $table = 'roles';
	public $timestamps = false;

	protected $casts = [
		'company_id' => 'int'
	];

	protected $fillable = [
		'company_id',
		'title',
		'description'
	];

	public function users()
	{
		return $this->hasMany(User::class);
	}
    public function groups()
    {
        return $this->belongsToMany(AbilityGroup::class, 'roles_ability',  'role_id', 'ability_id');
    }
    public function abilities()
    {
        return $this->belongsToMany(Abilities::class,'roles_ability',  'role_id', 'ability_id');
    }

    public function getAbilityIds()
    {
        return $this->abilities->pluck('title');
    }
}
