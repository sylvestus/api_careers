<?php

namespace App\Models\V1\Auth;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Abilities extends Model
{
    use HasFactory;

    protected $table = 'ability';

    protected $fillable = [
        'group_id',
        'title',
        'slug',
        'description',
    ];

    public function groups(){
        return $this->hasOne(AbilityGroup::class, 'id', 'group_id');
    }
}
