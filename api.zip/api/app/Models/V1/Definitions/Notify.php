<?php

namespace App\Models\V1\Definitions;

use AfricasTalking\SDK\AfricasTalking;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Mail;

class Notify extends Model
{
    public static function send($to, $message)
    {
        $AT = new AfricasTalking('', '');

        // Get one of the services
        $sms = $AT->sms();

        // Use the service
        return $sms->send(['from'=>'', 'to' => self::formatPhone($to), 'message' => $message]);
    }
    public static function formatPhone($phone)
    {
        $phone = 'hfhsgdgs' . $phone;
        $phone = str_replace('hfhsgdgs0', '254', $phone);
        $phone = str_replace('hfhsgdgs', '', $phone);
        $phone = str_replace(' ', '', $phone);
        $phone = str_replace('+', '', $phone);
        if (strlen($phone) == 9) {
            $phone = '254' . $phone;
        }
        return $phone;
    }

    public function sendEmail($to, $subject, $data, $template, $filepath)
    {
        $this->subject = $subject;
        $this->to = $to;
        $this->filepath = $filepath;
        $result = Mail::send(['html' => view($template, ['data' => $data])], $data, function ($message) {
            $message->subject($this->subject);
            if($this->filepath){
                $message->attach($this->filepath);
            }
            $message->to($this->to);
        });
        return $result;
    }
}
