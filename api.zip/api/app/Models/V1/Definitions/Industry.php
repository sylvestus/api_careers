<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\V1\Definitions;

use Illuminate\Database\Eloquent\Model;

/**
 * Class Industry
 * 
 * @property int $id
 * @property string $category
 * @property string $industry
 *
 * @package App\Models
 */
class Industry extends Model
{
	protected $table = 'industry';
	public $timestamps = false;

	protected $fillable = [
		'category',
		'industry'
	];
}
