<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\V1\Definitions;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

/**
 * Class BankBranch
 * 
 * @property int $id
 * @property int $bank_id
 * @property int $branch_code
 * @property string $bank_name
 * @property string $branch_name
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * 
 * @property Bank $bank
 *
 * @package App\Models
 */
class BankBranch extends Model
{
	protected $table = 'bank_branch';

	protected $casts = [
		'bank_id' => 'int',
		'branch_code' => 'int'
	];

	protected $fillable = [
		'bank_id',
		'branch_code',
		'bank_name',
		'branch_name'
	];

	public function bank()
	{
		return $this->belongsTo(Bank::class);
	}
}
