<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\V1\Definitions;

use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;

/**
 * Class Country
 * 
 * @property int $id
 * @property string $Country_Name
 * @property string|null $Official_Name_English
 * @property string|null $ISO3166_1_Alpha_2
 * @property string|null $ISO3166_1_Alpha_3
 * @property int|null $M49
 * @property string|null $ITU
 * @property string|null $MARC
 * @property string|null $WMO
 * @property string|null $DS
 * @property string|null $Dial
 * @property string|null $FIFA
 * @property string|null $FIPS
 * @property string|null $GAUL
 * @property string|null $IOC
 * @property string|null $ISO4217_Currency_Alphabetic_Code
 * @property string|null $ISO4217_Currency_Country_Name
 * @property int|null $ISO4217_Currency_Minor_Unit
 * @property string|null $ISO4217_Currency_Name
 * @property int|null $ISO4217_Currency_Numeric_Code
 * @property string|null $Is_Independent
 * @property string|null $Capital
 * @property string|null $Continent
 * @property string|null $TLD
 * @property string|null $Languages
 * @property string|null $Geo_Name_ID
 * @property string|null $EDGAR
 * 
 * @property Collection|BusinessProfile[] $business_profiles
 *
 * @package App\Models
 */
class Country extends Model
{
	protected $table = 'countries';
	public $timestamps = false;

	protected $casts = [
		'M49' => 'int',
		'ISO4217_Currency_Minor_Unit' => 'int',
		'ISO4217_Currency_Numeric_Code' => 'int'
	];

	protected $fillable = [
		'Country_Name',
		'Official_Name_English',
		'ISO3166_1_Alpha_2',
		'ISO3166_1_Alpha_3',
		'M49',
		'ITU',
		'MARC',
		'WMO',
		'DS',
		'Dial',
		'FIFA',
		'FIPS',
		'GAUL',
		'IOC',
		'ISO4217_Currency_Alphabetic_Code',
		'ISO4217_Currency_Country_Name',
		'ISO4217_Currency_Minor_Unit',
		'ISO4217_Currency_Name',
		'ISO4217_Currency_Numeric_Code',
		'Is_Independent',
		'Capital',
		'Continent',
		'TLD',
		'Languages',
		'Geo_Name_ID',
		'EDGAR'
	];
}
