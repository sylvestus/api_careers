<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\V1\Definitions;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;

/**
 * Class Bank
 * 
 * @property int $id
 * @property int $bankcode
 * @property string $bankname
 * @property string $paybill
 * @property string $swiftcode
 * @property string $bankbcc
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * 
 * @property Collection|BankBranch[] $bank_branches
 * @property Collection|Personnel[] $personnels
 *
 * @package App\Models
 */
class Bank extends Model
{
	protected $table = 'banks';

	protected $casts = [
		'bankcode' => 'int'
	];

	protected $fillable = [
		'bankcode',
		'bankname',
		'paybill',
		'swiftcode',
		'bankbcc'
	];

	public function bank_branches()
	{
		return $this->hasMany(BankBranch::class);
	}

	public function personnels()
	{
		return $this->hasMany(Personnel::class);
	}
}
