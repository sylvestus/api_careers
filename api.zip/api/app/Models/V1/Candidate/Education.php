<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\V1\Candidate;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

/**
 * Class Education
 * 
 * @property int $id
 * @property int $user_id
 * @property string $institution
 * @property Carbon $start_date
 * @property Carbon|null $end_date
 * @property string $course
 * @property string|null $grade
 * @property string|null $description
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * 
 * @property User $user
 *
 * @package App\Models
 */
class Education extends Model
{
	protected $table = 'education';

	protected $casts = [
		'user_id' => 'int'
	];

	protected $dates = [
		'start_date',
		'end_date'
	];

	protected $fillable = [
		'user_id',
		'institution',
		'start_date',
		'end_date',
		'course',
		'grade',
		'description'
	];

	public function user()
	{
		return $this->belongsTo(User::class);
	}
}
