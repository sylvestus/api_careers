<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\V1\Candidate;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

/**
 * Class Experience
 * 
 * @property int $id
 * @property int $user_id
 * @property string $employer
 * @property string $job_title
 * @property Carbon $start_date
 * @property Carbon|null $end_date
 * @property string|null $responsibilities
 * @property string|null $achievements
 * @property Carbon $created_at
 * @property Carbon $updated_at
 * 
 * @property User $user
 *
 * @package App\Models
 */
class Experience extends Model
{
	protected $table = 'experience';

	protected $casts = [
		'user_id' => 'int'
	];

	protected $dates = [
		'start_date',
		'end_date'
	];

	protected $fillable = [
		'user_id',
		'employer',
		'job_title',
		'start_date',
		'end_date',
		'responsibilities',
		'achievements'
	];

	public function user()
	{
		return $this->belongsTo(User::class);
	}
}
