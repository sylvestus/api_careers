<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models\V1\Candidate;

use App\Models\V1\Auth\User;
use App\Models\V1\Company\Company;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

/**
 * Class Document
 * 
 * @property int $id
 * @property int $company_id
 * @property int $user_id
 * @property string $document_type
 * @property string $filename
 * @property string $filesize
 * @property string $filetype
 * @property Carbon $created_at
 * @property Carbon|null $updated_at
 * 
 * @property Company $company
 * @property User $user
 *
 * @package App\Models
 */
class Document extends Model
{
	protected $table = 'documents';

	protected $casts = [
		'company_id' => 'int',
		'user_id' => 'int'
	];

	protected $fillable = [
		'company_id',
		'user_id',
		'document_type',
		'document_title',
		'filename',
		'filesize',
		'filetype'
	];

	public function company()
	{
		return $this->belongsTo(Company::class);
	}

	public function user()
	{
		return $this->belongsTo(User::class);
	}
}
