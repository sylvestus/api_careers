<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromCollection;

class QuickbooksExport implements FromCollection
{

    use Exportable;

    protected $items;

    public function __construct($items)
    {
        $this->items = $items;
    }

    public function headings(): array
    {
        return ["Date", "Description", "Credit", "Debit"];
    }

    public function collection()
    {
        $data = [];
        $data[] = ["Date", "Description", "Credit", "Debit"];
        foreach ($this->items as $row) {
            if ($row->beneficiary_details) {
                if ($row->beneficiary_details == "SAFCOM") {
                    $payment = $row->beneficiary_account . " - " . $row->expense;
                } else if ($row->beneficiary_details == "PDSLPREPAID") {
                    $payment = $row->beneficiary_account . " - KPLC PREPAID";
                } else if ($row->payment_method == "BANK") {
                    $payment = $row->beneficiary_account . " " . $row->beneficiary_name . " - " .  $row->expense;
                } else {
                    $payment = $row->beneficiary_details;
                }
            } else {
                $payment = $row->beneficiary_account . " - " . $row->expense;
            }
            $data[] = [date("d/m/Y", strtotime($row->created_at)),  $row->expense . " - " . $payment, null, $row->amount];
        }
        return collect($data);
    }
}
