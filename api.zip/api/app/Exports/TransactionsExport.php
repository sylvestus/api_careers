<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromCollection;

class TransactionsExport implements FromCollection
{

    use Exportable;

    protected $items;

    public function __construct($items)
    {
        $this->items = $items;
    }

    public function headings(): array
    {
        return ["Reference", "Description", "Credit", "Debit", "Fee", "Date"];
    }

    public function collection()
    {
        $data = [];

        $fee = 0;
        $amount = 0;
        $credits = 0;
        $debits = 0;
        $data[] = ["Reference", "Description", "Credit", "Debit", "Fee", "Date"];
        foreach ($this->items as $row) {
            $fee += $row->fee;
            $amount += $row->amount;
            if($row->type=='credit'){
                $credits += ($row->amount - $row->fee);
            }
            if($row->type=='debit'){
                $debits += ($row->amount - $row->fee);
            }
            $data[] = [$row->reference, $row->description, $row->type=='credit' ? number_format($row->amount, 2) : null, $row->type=='debit' ? number_format($row->amount, 2) : null, number_format($row->fee, 2), $row->created_at];
        }
        $data[] = ["Totals", "", number_format($credits, 2),  number_format($debits, 2), number_format($fee, 2), number_format($credits-$debits-$fee, 2)];
        return collect($data);
    }
}
