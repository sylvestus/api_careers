<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromCollection;

class PayrollMusterRollExport implements FromCollection
{

    use Exportable;

    protected $items;

    public function __construct($items)
    {
        $this->items = $items;
    }

    public function headings(): array
    {
        return ["Employee", "Basic Salary", "PAYE", "Withholding Tax", "NHIF", "NSSF", "Deductions", "Net Pay"];
    }

    public function collection()
    {
        $data = [];

        $gross_salary = 0;
        $paye = 0;
        $withholding = 0;
        $nhif = 0;
        $nssf_employee = 0;
        $deductions = 0;
        $net_pay = 0;

        $data[] = ["Employee", "Basic Salary", "PAYE", "Withholding Tax", "NHIF", "NSSF", "Deductions", "Net Pay"];
        foreach ($this->items as $row) {
            $gross_salary += $row['gross_salary'];
            $paye += $row['paye'];
            $withholding += $row['withholding'];
            $nhif += $row['nhif'];
            $nssf_employee += $row['nssf_employee'];
            $deductions += $row['deductions'];
            $net_pay += $row['net_pay'];

            $data[] = [$row['employee'], number_format($row['gross_salary'], 2), number_format($row['paye'], 2), number_format($row['withholding'], 2), number_format($row['nhif'], 2), number_format($row['nssf_employee'], 2), number_format($row['deductions'], 2), number_format($row['net_pay'], 2)];
        }
        $data[] = ["", number_format($gross_salary, 2), number_format($paye, 2), number_format($withholding, 2), number_format($nhif, 2), number_format($nssf_employee, 2), number_format($deductions, 2), number_format($net_pay, 2)];
        return collect($data);
    }
}
