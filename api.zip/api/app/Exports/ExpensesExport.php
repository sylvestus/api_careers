<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromCollection;

class ExpensesExport implements FromCollection
{

    use Exportable;

    protected $items;

    public function __construct($items)
    {
        $this->items = $items;
    }

    public function headings(): array
    {
        return ["Reference", "Employee", "Category", "Expense", "Date", "Status", "Fee", "Amount"];
    }

    public function collection()
    {
        $data = [];

        $fee = 0;
        $amount = 0;
        $data[] = ["Reference", "Employee", "Category", "Expense", "Date", "Status", "Fee", "Amount"];
        foreach ($this->items as $row) {
            $fee += $row->fee;
            $amount += $row->amount;
            if ($row->status = 1) {
                $status = "Completed";
            } elseif ($row->status = 2) {
                $status = "Failed";
            } else {
                $status = "Pending";
            }
            if ($row->beneficiary_details) {
                if ($row->beneficiary_details == "SAFCOM") {
                    $payment = $row->beneficiary_account . " - " . $row->expense;
                } else if ($row->beneficiary_details == "PDSLPREPAID") {
                    $payment = $row->beneficiary_account . " - KPLC PREPAID";
                } else if ($row->payment_method == "BANK") {
                    $payment = $row->beneficiary_account . " " . $row->beneficiary_name. " - " .  $row->expense;
                } else {
                    $payment = $row->beneficiary_details;
                }
            } else {
                $payment = $row->beneficiary_account . " - " . $row->expense;
            }

            $category = isset($row->expense_category->category) ? $row->expense_category->category : null;
            $data[] = [$row->reference, $row->personnel->first_name . " " . $row->personnel->middle_name . " " . $row->personnel->last_name, $category, $row->expense . " - " . $payment, $row->created_at, $status, number_format($row->fee, 2), number_format($row->amount, 2)];
        }
        $data[] = ["Grant Total", "", "", "", "",  "", number_format($fee, 2), number_format($amount, 2)];
        return collect($data);
    }
}
