<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromCollection;

class QuickbooksDesktopExport implements FromCollection
{

    use Exportable;

    protected $items;

    public function __construct($items)
    {
        $this->items = $items;
    }

    public function headings(): array
    {
        return ["DATE", "NUMBER", "MEMO", "ACCOUNT", "VAT", "AMOUNT"];
    }

    public function collection()
    {
        $data = [];
        $data[] = ["DATE", "NUMBER", "MEMO", "ACCOUNT", "VAT", "AMOUNT"];
        foreach ($this->items as $row) {
            if ($row->beneficiary_details) {
                if ($row->beneficiary_details == "SAFCOM") {
                    $payment = $row->beneficiary_account . " - " . $row->expense;
                } else if ($row->beneficiary_details == "PDSLPREPAID") {
                    $payment = $row->beneficiary_account . " - KPLC PREPAID";
                } else if ($row->payment_method == "BANK") {
                    $payment = $row->beneficiary_account . " " . $row->beneficiary_name . " - " .  $row->expense;
                } else {
                    $payment = $row->beneficiary_details;
                }
            } else {
                $payment = $row->beneficiary_account . " - " . $row->expense;
            }
            $data[] = [date("d/m/Y", strtotime($row->created_at)), $row->reference,  " " . $payment, "Office Expense", "S", $row->amount];
        }
        return collect($data);
    }
}
